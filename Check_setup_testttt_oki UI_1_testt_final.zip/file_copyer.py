from PyQt6 import QtWidgets, QtGui, QtCore
from PyQt6.QtCore import Qt, QSize
from PyQt6.QtWidgets import QGraphicsBlurEffect
import os
import pandas as pd
from datetime import datetime
import shutil
import sys
import subprocess
import json

from settings_dialog import SettingsDialog # Import the SettingsDialog
from ui_file_copyer import Ui_MainWindow # Import the UI from new file

# Import MainWindows from other apps with aliases
from sequence_verify import XMLComparisonApp as SequenceVerifyApp
from ini_verify import MainWindow as IniVerifyApp
from dll_verify import MainWindow as DllVerifyApp

def get_script_dir():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    else:
        return os.path.dirname(os.path.realpath(__file__))

script_dir = get_script_dir()
df = pd.read_csv("IP_List_PUC.csv", index_col=None, sep=',', header=0)

class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        self.line_checkboxes = {}
        app_icon = QtGui.QIcon(":/icons/app_icon.png")
        self.setWindowIcon(app_icon)
        
        # Initialize history lists (moved here before load_settings)
        self.common_path_mono_history = []
        self.filename_mono_history = []
        self.common_path_color_history = []
        self.filename_color_history = []

        self.load_settings()
        # self.update_comboboxes() # Removed as comboboxes are replaced by QLineEdit
        self.setup_connections()
        self.update_line_checkboxes()
        
        # Dictionary to hold references to child windows
        self.child_windows = {}
        
        # Connect reset buttons
        # Note: The UI for these buttons is created in ui_file_copyer.py and connected there.
        # If reset buttons are to be managed from file_copyer.py, they need to be exposed as attributes in Ui_MainWindow.
        # For now, I'll assume direct connection in ui_file_copyer.py is sufficient for basic clear.

    def setup_connections(self):
        self.ui.settings_button.clicked.connect(self.open_settings)
        self.ui.copy_mono_button.clicked.connect(self.copy_and_rename_files)
        self.ui.copy_color_button.clicked.connect(self.copy_and_rename_color)
        self.ui.sequence_check_button.clicked.connect(lambda: self.open_check_app("sequence_verify.py"))
        self.ui.ini_check_button.clicked.connect(lambda: self.open_check_app("ini_verify.py"))
        self.ui.dll_check_button.clicked.connect(lambda: self.open_check_app("dll_verify.py"))

        self.ui.reset_all_history_button.clicked.connect(self.reset_all_history)

    def open_check_app(self, script_name):
        try:
            self.apply_blur() # Apply blur before opening any child window

            if script_name == "sequence_verify.py":
                if "sequence_verify" not in self.child_windows or not self.child_windows["sequence_verify"].isVisible():
                    self.child_windows["sequence_verify"] = SequenceVerifyApp(parent=self) # Pass self as parent
                    # self.child_windows["sequence_verify"].finished.connect(self.remove_blur) # Removed invalid connection
                    self.child_windows["sequence_verify"].show()
                    self.update_log(f"Opened Sequence Verify App")
                else:
                    self.child_windows["sequence_verify"].activateWindow()
                    self.child_windows["sequence_verify"].raise_()
            elif script_name == "ini_verify.py":
                if "ini_verify" not in self.child_windows or not self.child_windows["ini_verify"].isVisible():
                    self.child_windows["ini_verify"] = IniVerifyApp(parent=self) # Pass self as parent
                    # self.child_windows["ini_verify"].finished.connect(self.remove_blur) # Removed invalid connection
                    self.child_windows["ini_verify"].show()
                    self.update_log(f"Opened INI Verify App")
                else:
                    self.child_windows["ini_verify"].activateWindow()
                    self.child_windows["ini_verify"].raise_()
            elif script_name == "dll_verify.py":
                if "dll_verify" not in self.child_windows or not self.child_windows["dll_verify"].isVisible():
                    self.child_windows["dll_verify"] = DllVerifyApp(parent=self) # Pass self as parent
                    # self.child_windows["dll_verify"].finished.connect(self.remove_blur) # Removed invalid connection
                    self.child_windows["dll_verify"].show()
                    self.update_log(f"Opened DLL Verify App")
                else:
                    self.child_windows["dll_verify"].activateWindow()
                    self.child_windows["dll_verify"].raise_()
            else:
                self.update_log(f"Error: Unknown application {script_name}", "error")
                QtWidgets.QMessageBox.critical(self, "Error", f"Unknown application: {script_name}")

        except Exception as e:
            self.update_log(f"Error when opening {script_name}: {str(e)}", "error")
            QtWidgets.QMessageBox.critical(self, "Error", f"Could not open {script_name}: {str(e)}")
            self.remove_blur() # Ensure blur is removed even if an error occurs


    def copy_and_rename_files(self):
        common_path = self.ui.common_path_mono.currentText().strip()
        filename_to_copy = self.ui.filename_mono.currentText().strip()
        
        # Add current inputs to history
        self.add_to_history(self.common_path_mono_history, common_path)
        self.add_to_history(self.filename_mono_history, filename_to_copy)
        
        self.save_settings() # Save history immediately after adding new entry
        
        if not common_path:
            QtWidgets.QMessageBox.critical(self, "Error", "Please enter a common path for MONO sequence files.")
            return
        if not filename_to_copy:
            QtWidgets.QMessageBox.critical(self, "Error", "Please enter a filename to copy for MONO sequence files.")
            return

        selected_lines = [line for line, checkbox in self.line_checkboxes.items() if checkbox.isChecked()]
        if not selected_lines:
            QtWidgets.QMessageBox.critical(self, "Error", "Please select at least one line")
            return

        confirmation = QtWidgets.QMessageBox.question(self, "Confirmation", f"Are you sure you want to copy and rename file '{filename_to_copy}' from path '{common_path}' for lines {', '.join(selected_lines)}?")
        if confirmation != QtWidgets.QMessageBox.StandardButton.Yes:
            return

        dest_dir = os.path.join(script_dir, "Radiant Sequence", filename_to_copy.split('.')[0]) # Use base filename for folder
        if not os.path.exists(dest_dir):
            os.makedirs(dest_dir)

        inaccessible_pcs = []
        missing_files = []
        successful_pcs = []

        self.update_log(f"Starting copy and rename process for {filename_to_copy} from {common_path}")

        for _, row in df.iterrows():
            if any(line in row["MONO"] for line in selected_lines):
                name, ip = row["MONO"], row["IP1"]
                
                if not self.try_network_access(ip):
                    inaccessible_pcs.append(f"{name} ({ip})")
                    continue
                
                # Construct src_file using common_path and filename_to_copy
                src_file = f"\\\\{ip}\\{common_path.replace(':', '$')}\\{filename_to_copy}"
                self.update_log(f"Processing {name} ({ip})... Trying to copy {src_file}")

                temp_file = f"{filename_to_copy}.tmp"

                try:
                    if not os.path.exists(src_file):
                        missing_files.append(f"{name} ({ip})")
                        self.update_log(f"File not found on {name} ({ip}): {src_file}", "warning")
                        continue

                    shutil.copy2(src_file, os.path.join(dest_dir, temp_file))
                    # Rename with prefix 'name_' (e.g., PUC1_#1 CAM #1_) and original filename
                    dest_file = os.path.join(dest_dir, f"{name}_{filename_to_copy}")
                    os.rename(os.path.join(dest_dir, temp_file), dest_file)
                    self.update_log(f"Success: Copied {filename_to_copy} from {name} ({ip}) to {dest_file}", "success")
                    successful_pcs.append(f"{name} ({ip})")
                except Exception as e:
                    self.update_log(f"Error accessing {name} ({ip}) or copying file: {e}", "error")
                    inaccessible_pcs.append(f"{name} ({ip})")
                    continue

        report = []
        if successful_pcs:
            report.append("Successfully copied from:")
            report.extend([f"  - {pc}" for pc in successful_pcs])
            report.append("")
        
        if inaccessible_pcs:
            report.append("Could not access these PCs or encountered errors:")
            report.extend([f"  - {pc}" for pc in inaccessible_pcs])
            report.append("")
        
        if missing_files:
            report.append("File not found on these PCs:")
            report.extend([f"  - {pc}" for pc in missing_files])

        report_text = "\n".join(report)
        self.update_log("\nCopy process completed!")
        self.update_log(report_text)

        if not (inaccessible_pcs or missing_files):
            QtWidgets.QMessageBox.information(
                self,
                "Success",
                f"Successfully copied files from all {len(successful_pcs)} PCs!"
            )
        else:
            QtWidgets.QMessageBox.warning(
                self,
                "Process Completed with Issues",
                f"Process completed with following results:\n\n{report_text}"
            )

    def copy_and_rename_color(self):
        common_path = self.ui.common_path_color.currentText().strip()
        filename_to_copy = self.ui.filename_color.currentText().strip()
        
        # Add current inputs to history
        self.add_to_history(self.common_path_color_history, common_path)
        self.add_to_history(self.filename_color_history, filename_to_copy)
        
        self.save_settings() # Save history immediately after adding new entry
        
        if not common_path:
            QtWidgets.QMessageBox.critical(self, "Error", "Please enter a common path for COLOR sequence files.")
            return
        if not filename_to_copy:
            QtWidgets.QMessageBox.critical(self, "Error", "Please enter a filename to copy for COLOR sequence files.")
            return

        selected_lines = [line for line, checkbox in self.line_checkboxes.items() if checkbox.isChecked()]
        if not selected_lines:
            QtWidgets.QMessageBox.critical(self, "Error", "Please select at least one line")
            return

        confirmation = QtWidgets.QMessageBox.question(self, "Confirmation", f"Are you sure you want to copy and rename file '{filename_to_copy}' from path '{common_path}' for lines {', '.join(selected_lines)}?")
        if confirmation != QtWidgets.QMessageBox.StandardButton.Yes:
            return

        dest_dir = os.path.join(script_dir, "Radiant Sequence", filename_to_copy.split('.')[0]) # Use base filename for folder
        if not os.path.exists(dest_dir):
            os.makedirs(dest_dir)

        inaccessible_pcs = []
        missing_files = []
        successful_pcs = []

        self.update_log(f"Starting copy and rename process for {filename_to_copy} from {common_path}")

        for _, row in df.iterrows():
            if any(line in row["COLOR"] for line in selected_lines):
                name, ip = row["COLOR"], row["IP2"]
                
                if not self.try_network_access(ip):
                    inaccessible_pcs.append(f"{name} ({ip})")
                    continue
                
                # Construct src_file using common_path and filename_to_copy
                src_file = f"\\\\{ip}\\{common_path.replace(':', '$')}\\{filename_to_copy}"
                self.update_log(f"Processing {name} ({ip})... Trying to copy {src_file}")

                temp_file = f"{filename_to_copy}.tmp"

                try:
                    if not os.path.exists(src_file):
                        missing_files.append(f"{name} ({ip})")
                        self.update_log(f"File not found on {name} ({ip}): {src_file}", "warning")
                        continue

                    shutil.copy2(src_file, os.path.join(dest_dir, temp_file))
                    # Rename with prefix 'name_' (e.g., PUC1_#1 CAM #1_) and original filename
                    dest_file = os.path.join(dest_dir, f"{name}_{filename_to_copy}")
                    os.rename(os.path.join(dest_dir, temp_file), dest_file)
                    self.update_log(f"Success: Copied {filename_to_copy} from {name} ({ip}) to {dest_file}", "success")
                    successful_pcs.append(f"{name} ({ip})")
                except Exception as e:
                    self.update_log(f"Error accessing {name} ({ip}) or copying file: {e}", "error")
                    inaccessible_pcs.append(f"{name} ({ip})")
                    continue

        report = []
        if successful_pcs:
            report.append("Successfully copied from:")
            report.extend([f"  - {pc}" for pc in successful_pcs])
            report.append("")
        
        if inaccessible_pcs:
            report.append("Could not access these PCs or encountered errors:")
            report.extend([f"  - {pc}" for pc in inaccessible_pcs])
            report.append("")
        
        if missing_files:
            report.append("File not found on these PCs:")
            report.extend([f"  - {pc}" for pc in missing_files])

        report_text = "\n".join(report)
        self.update_log("\nCopy process completed!")
        self.update_log(report_text)

        if not (inaccessible_pcs or missing_files):
            QtWidgets.QMessageBox.information(
                self,
                "Success",
                f"Successfully copied files from all {len(successful_pcs)} PCs!"
            )
        else:
            QtWidgets.QMessageBox.warning(
                self,
                "Process Completed with Issues",
                f"Process completed with following results:\n\n{report_text}"
            )

    def update_log(self, message, message_type="info"):
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        if message_type == "error":
            log_message = f'<span style="color:red;">[{current_time}] {message}</span>'
        elif message_type == "warning":
            log_message = f'<span style="color:orange;">[{current_time}] {message}</span>'
        else:
            log_message = f"[{current_time}] {message}"
        self.ui.log_text.append(log_message)
        self.ui.log_text.ensureCursorVisible()
        QtWidgets.QApplication.processEvents()  # Update UI immediately

    def open_settings(self):
        dialog = SettingsDialog(self)

        # Truyền line_settings và credentials cho dialog
        dialog.load_lines_settings(self.line_settings)
        dialog.load_credentials_settings(self.credentials)
        
        self.apply_blur()
        if dialog.exec() == QtWidgets.QDialog.DialogCode.Accepted:

            # Update the internal lists with the possibly modified lists from the dialog
            
            # Lưu credentials
            self.credentials = [
                {"username": cred.split('/')[0], "password": cred.split('/')[1]}
                for cred in [dialog.credentials_list.item(i).text() 
                           for i in range(dialog.credentials_list.count())]
            ]
            
            # Lưu line settings
            self.line_settings = [dialog.lines_list.item(i).text() 
                                for i in range(dialog.lines_list.count())]
            
            # Lưu tất cả các thay đổi vào một file
            self.save_settings()
            
            # Cập nhật UI (chỉ line checkboxes)
            self.update_line_checkboxes()
        
        self.remove_blur()

    def add_to_history(self, history_list, text):
        if text and text.strip() and text.strip() not in history_list:
            history_list.insert(0, text.strip()) # Add to the beginning and strip whitespace
            if len(history_list) > 10: # Limit history size
                history_list.pop() # Remove oldest item
            self.save_settings() # Save settings immediately after history changes

    def reset_history(self, combo_box, history_list, default_value=""):
        history_list.clear()
        combo_box.clear()
        combo_box.addItem(default_value)
        combo_box.setCurrentText(default_value)

    def reset_all_history(self):
        confirmation = QtWidgets.QMessageBox.question(self, "Confirm Reset", "Are you sure you want to clear all history for common paths and filenames?",
                                                QtWidgets.QMessageBox.StandardButton.Yes | QtWidgets.QMessageBox.StandardButton.No)
        if confirmation == QtWidgets.QMessageBox.StandardButton.No:
            return
            
        self.reset_history(self.ui.common_path_mono, self.common_path_mono_history, self.mono_common_path)
        self.reset_history(self.ui.filename_mono, self.filename_mono_history, self.mono_sequence_filename)
        self.reset_history(self.ui.common_path_color, self.common_path_color_history, self.color_common_path)
        self.reset_history(self.ui.filename_color, self.filename_color_history, self.color_sequence_filename)
        self.save_settings() # Save empty history to file
        self.update_log("All history cleared.", "info")
        
    def apply_blur(self):
        self.blur_effect = QGraphicsBlurEffect()
        self.blur_effect.setBlurRadius(5)  # Adjust blur radius as needed
        self.centralWidget().setGraphicsEffect(self.blur_effect)

    def remove_blur(self):
        self.centralWidget().setGraphicsEffect(None)

    def save_settings(self):
        # Update current values from UI before saving
        self.mono_common_path = self.ui.common_path_mono.currentText().strip()
        self.mono_sequence_filename = self.ui.filename_mono.currentText().strip()
        self.color_common_path = self.ui.common_path_color.currentText().strip()
        self.color_sequence_filename = self.ui.filename_color.currentText().strip()
        
        settings = {

            "mono_common_path": self.mono_common_path,
            "mono_sequence_filename": self.mono_sequence_filename,
            "color_common_path": self.color_common_path,
            "color_sequence_filename": self.color_sequence_filename,
            
            "common_path_mono_history": self.common_path_mono_history,
            "filename_mono_history": self.filename_mono_history,
            "common_path_color_history": self.common_path_color_history,
            "filename_color_history": self.filename_color_history,
            
            # Line settings
            "line_settings": self.line_settings,
            
            # Credentials
            "credentials": self.credentials
        }
        with open("app_settings.json", "w") as f:
            json.dump(settings, f, indent=4)

    def load_settings(self):
        try:
            with open("app_settings.json", "r") as f:
                settings = json.load(f)
                # Load sequence và INI filenames
                # These are no longer directly used by main window for copy operations, but kept for settings dialog
                self.mono_common_path = settings.get("mono_common_path", "C:\\Radiant Vision Systems Data\\TrueTest\\SEQUENCE") # Corrected default path format
                self.mono_sequence_filename = settings.get("mono_sequence_filename", "X2146_Mono_MP_Glossy_ver1.seqxc")
                
                self.color_common_path = settings.get("color_common_path", "C:\\Radiant Vision Systems Data\\TrueTest\\SEQUENCE") # Corrected default path format
                self.color_sequence_filename = settings.get("color_sequence_filename", "X2146-Color-MP-Glossy-ver1.seqxc")
                
                # Load history lists
                self.common_path_mono_history = settings.get("common_path_mono_history", [])
                self.filename_mono_history = settings.get("filename_mono_history", [])
                self.common_path_color_history = settings.get("common_path_color_history", [])
                self.filename_color_history = settings.get("filename_color_history", [])
                
                # Populate combo boxes with history and set current text
                self._populate_combo_box(self.ui.common_path_mono, self.common_path_mono_history, self.mono_common_path)
                self._populate_combo_box(self.ui.filename_mono, self.filename_mono_history, self.mono_sequence_filename)
                self._populate_combo_box(self.ui.common_path_color, self.common_path_color_history, self.color_common_path)
                self._populate_combo_box(self.ui.filename_color, self.filename_color_history, self.color_sequence_filename)

                # Load line settings
                self.line_settings = settings.get("line_settings", ["501", "502", "503", "504"])
                
                # Load credentials
                self.credentials = settings.get("credentials", [{"username": "user", "password": "1"}])
                
        except FileNotFoundError:
            # Sử dụng giá trị mặc định nếu không tìm thấy file
            self.mono_common_path = "c\\Radiant Vision Systems Data\\TrueTest\\SEQUENCE" # Original default path format
            self.mono_sequence_filename = "X2146_Mono_MP_Glossy_ver1.seqxc"
            
            self.color_common_path = "c\\Radiant Vision Systems Data\\TrueTest\\SEQUENCE" # Original default path format
            self.color_sequence_filename = "X2146-Color-MP-Glossy-ver1.seqxc"
            
            self.line_settings = ["501", "502", "503", "504"]
            self.credentials = [{"username": "user", "password": "1"}]
            
            # Populate combo boxes with default values if FileNotFoundError
            self._populate_combo_box(self.ui.common_path_mono, self.common_path_mono_history, self.mono_common_path)
            self._populate_combo_box(self.ui.filename_mono, self.filename_mono_history, self.mono_sequence_filename)
            self._populate_combo_box(self.ui.common_path_color, self.common_path_color_history, self.color_common_path)
            self._populate_combo_box(self.ui.filename_color, self.filename_color_history, self.color_sequence_filename)

    def _populate_combo_box(self, combo_box, history_list, default_value):
        combo_box.clear()
        
        unique_items = []
        seen = set()

        # Add default_value first if it's not empty
        if default_value:
            unique_items.append(default_value)
            seen.add(default_value)

        # Then add history items, skipping duplicates
        for item in history_list:
            if item and item not in seen:
                unique_items.append(item)
                seen.add(item)

        # Populate the combo box with the prepared list
        combo_box.addItems(unique_items)
        
        # Set the current text, prioritizing default_value
        if default_value:
            combo_box.setCurrentText(default_value)
        elif unique_items:
            combo_box.setCurrentText(unique_items[0])
            

    def try_network_access(self, ip):
        """Thử kết nối với các credential khác nhau"""
        success = False
        error_messages = []
        
        for cred in self.credentials:
            try:             
                # Thử kết nối với credential hiện tại
                cmd = f'net use \\{ip} /user:{cred["username"]} {cred["password"]}'
                result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
                
                if result.returncode == 0:
                    success = True
                    self.update_log(f"Successfully connected to {ip} with user {cred['username']}")
                    break
                else:
                    error_messages.append(f"Failed with {cred['username']}: {result.stderr}")
            except Exception as e:
                error_messages.append(f"Error with {cred['username']}: {str(e)}")
        
        if not success:
            error_msg = "\n".join(error_messages)
            self.update_log(f"Failed to connect to {ip}. Errors:\n{error_msg}")
        
        return success

    def update_line_checkboxes(self):
        # Tạo layout mới
        current_line_layout = self.ui.line_card.layout()
        if current_line_layout is None:
            current_line_layout = QtWidgets.QHBoxLayout(self.ui.line_card)
            current_line_layout.setContentsMargins(10, 5, 10, 5)
            current_line_layout.setSpacing(15)

        # Xóa các checkbox cũ khỏi layout hiện có
        while current_line_layout.count():
            item = current_line_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        
        # Thêm checkbox mới
        for line in self.line_settings:
            checkbox = QtWidgets.QCheckBox(f"Line {line}")
            checkbox.setStyleSheet("""
                QCheckBox {
                    font-size: 11px;
                }
                QCheckBox::indicator {
                    width: 16px;
                    height: 16px;
                    border: 1.5px solid #546de5;
                    border-radius: 3px;
                    /* image: url(:/icons/checkbox_unchecked.png); */
                }
                QCheckBox::indicator:checked {
                    background-color: #546de5;
                    image: url(:/icons/check.png);
                }
            """)
            self.line_checkboxes[line] = checkbox
            current_line_layout.addWidget(checkbox)

    def closeEvent(self, event):
        self.save_settings()
        event.accept()

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())