from PyQt6 import QtWidgets, QtGui, QtCore
from PyQt6.QtCore import Qt

class SettingsDialog(QtWidgets.QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Settings")
        self.resize(400, 500)
        
        layout = QtWidgets.QVBoxLayout(self)
        
        self.tabs = QtWidgets.QTabWidget()
        self.tabs.setStyleSheet("""
            QTabWidget::pane {
                border: 1px solid #ccc;
                background-color: #f0f0f0;
            }
            QTabBar::tab {
                background: #e0e0e0;
                border: 1px solid #c4c4c4;
                border-bottom-color: #c2c2c2; /* same as pane color */
                border-top-left-radius: 4px;
                border-top-right-radius: 4px;
                min-width: 8ex;
                padding: 2px 8px;
                color: #333;
            }
            QTabBar::tab:selected {
                background: #fff;
                border-color: #c4c4c4;
                border-bottom-color: #fff; /* make bottom border transparent for selected tab */
                color: #000;
            }
            QTabBar::tab:hover {
                background: #f0f0f0;
            }
        """)
        layout.addWidget(self.tabs)
        
        self.mono_tab = QtWidgets.QWidget()
        self.color_tab = QtWidgets.QWidget()
        self.management_tab = QtWidgets.QWidget() # New tab
        
        self.tabs.addTab(self.management_tab, "MANAGEMENT") # Add new tab
        
        self.setup_management_tab() # Call the new setup method
        
        buttons = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.StandardButton.Ok | QtWidgets.QDialogButtonBox.StandardButton.Cancel,
            Qt.Orientation.Horizontal, self)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        
        # Apply custom styling to the buttons
        ok_button = buttons.button(QtWidgets.QDialogButtonBox.StandardButton.Ok)
        cancel_button = buttons.button(QtWidgets.QDialogButtonBox.StandardButton.Cancel)
        
        ok_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50; /* Green */
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-weight: bold;
                min-width: 80px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
            QPushButton:pressed {
                background-color: #398439;
            }
        """)
        
        cancel_button.setStyleSheet("""
            QPushButton {
                background-color: #f44336; /* Red */
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-weight: bold;
                min-width: 80px;
            }
            QPushButton:hover {
                background-color: #da190b;
            }
            QPushButton:pressed {
                background-color: #b01308;
            }
        """)

    def setup_management_tab(self):
        self.management_tab_layout = QtWidgets.QVBoxLayout(self.management_tab)
        
        # Lines section
        lines_group = QtWidgets.QGroupBox("Line Settings")
        self.lines_group_layout = QtWidgets.QVBoxLayout(lines_group)
        
        self.lines_list = QtWidgets.QListWidget(lines_group)
        self.lines_list.setStyleSheet("""
            QListWidget {{
                border: 2px solid #546de5;
                border-radius: 5px;
                padding: 5px;
            }}
            QListWidget::item {{
                padding: 8px;
                border-bottom: 1px solid #e0e0e0;
            }}
            QListWidget::item:selected {{
                background-color: #546de5;
                color: white;
            }}
        """)
        self.lines_group_layout.addWidget(self.lines_list)
        
        buttons_layout = QtWidgets.QHBoxLayout()
        
        self.add_line_button = self.create_styled_button("Add Line", ":/icons/add.png", "#28a745") # Green
        self.add_line_button.clicked.connect(self.add_line)
        
        self.edit_line_button = self.create_styled_button("Edit Line", ":/icons/edit.png", "#ffc107") # Yellow
        self.edit_line_button.clicked.connect(self.edit_line)
        
        self.delete_line_button = self.create_styled_button("Delete Line", ":/icons/delete.png", "#dc3545") # Red
        self.delete_line_button.clicked.connect(self.delete_line)
        
        buttons_layout.addWidget(self.add_line_button)
        buttons_layout.addWidget(self.edit_line_button)
        buttons_layout.addWidget(self.delete_line_button)
        
        self.lines_group_layout.addLayout(buttons_layout)
        
        # Credentials section
        credentials_group = QtWidgets.QGroupBox("Credential Settings")
        self.credentials_group_layout = QtWidgets.QVBoxLayout(credentials_group)
        
        self.credentials_list = QtWidgets.QListWidget(credentials_group)
        self.credentials_list.setStyleSheet("""
            QListWidget {{
                border: 2px solid #546de5;
                border-radius: 5px;
                padding: 5px;
            }}
            QListWidget::item {{
                padding: 8px;
                border-bottom: 1px solid #e0e0e0;
            }}
            QListWidget::item:selected {{
                background-color: #546de5;
                color: white;
            }}
        """)
        self.credentials_group_layout.addWidget(self.credentials_list)
        
        buttons_layout_cred = QtWidgets.QHBoxLayout()
        
        self.add_cred_button = self.create_styled_button("Add Credential", ":/icons/add.png", "#28a745") # Green
        self.add_cred_button.clicked.connect(self.add_credential)
        
        self.edit_cred_button = self.create_styled_button("Edit Credential", ":/icons/edit.png", "#ffc107") # Yellow
        self.edit_cred_button.clicked.connect(self.edit_credential)
        
        self.delete_cred_button = self.create_styled_button("Delete Credential", ":/icons/delete.png", "#dc3545") # Red
        self.delete_cred_button.clicked.connect(self.delete_credential)
        
        buttons_layout_cred.addWidget(self.add_cred_button)
        buttons_layout_cred.addWidget(self.edit_cred_button)
        buttons_layout_cred.addWidget(self.delete_cred_button)
        
        self.credentials_group_layout.addLayout(buttons_layout_cred)
        
        self.management_tab_layout.addWidget(lines_group)
        self.management_tab_layout.addWidget(credentials_group)

    def load_lines_settings(self, line_settings):
        self.lines_list.clear()
        for line in line_settings:
            self.lines_list.addItem(line)

    def add_line(self):
        line_number, ok = QtWidgets.QInputDialog.getText(
            self, 'Add Line', 'Enter line number:',
            QtWidgets.QLineEdit.EchoMode.Normal)
        
        if ok and line_number:
            if not line_number.strip():
                QtWidgets.QMessageBox.warning(self, "Warning", "Line number cannot be empty!")
                return
                
            existing_items = [self.lines_list.item(i).text() for i in range(self.lines_list.count())]
            if line_number in existing_items:
                QtWidgets.QMessageBox.warning(self, "Warning", "This line already exists!")
                return
                
            self.lines_list.addItem(line_number)

    def edit_line(self):
        current_item = self.lines_list.currentItem()
        if not current_item:
            QtWidgets.QMessageBox.warning(self, "Warning", "Please select a line to edit!")
            return
            
        line_number, ok = QtWidgets.QInputDialog.getText(
            self, 'Edit Line', 'Enter new line number:',
            QtWidgets.QLineEdit.EchoMode.Normal, current_item.text())
            
        if ok and line_number:
            if not line_number.strip():
                QtWidgets.QMessageBox.warning(self, "Warning", "Line number cannot be empty!")
                return
                
            existing_items = [self.lines_list.item(i).text() for i in range(self.lines_list.count())
                            if i != self.lines_list.row(current_item)]
            if line_number in existing_items:
                QtWidgets.QMessageBox.warning(self, "Warning", "This line already exists!")
                return
                
            current_item.setText(line_number)

    def delete_line(self):
        current_item = self.lines_list.currentItem()
        if not current_item:
            QtWidgets.QMessageBox.warning(self, "Warning", "Please select a line to delete!")
            return
            
        reply = QtWidgets.QMessageBox.question(
            self, 'Delete Line',
            f'Are you sure you want to delete line {current_item.text()}?',
            QtWidgets.QMessageBox.StandardButton.Yes | QtWidgets.QMessageBox.StandardButton.No
        )
        
        if reply == QtWidgets.QMessageBox.StandardButton.Yes:
            self.lines_list.takeItem(self.lines_list.row(current_item))

    def load_credentials_settings(self, credentials):
        self.credentials_list.clear()
        for cred in credentials:
            self.credentials_list.addItem(f"{cred['username']}/{cred['password']}")

    def add_credential(self):
        dialog = CredentialDialog(self)
        if dialog.exec() == QtWidgets.QDialog.DialogCode.Accepted:
            username = dialog.username_input.text().strip()
            password = dialog.password_input.text().strip()
            if username and password:
                self.credentials_list.addItem(f"{username}/{password}")

    def edit_credential(self):
        current_item = self.credentials_list.currentItem()
        if not current_item:
            QtWidgets.QMessageBox.warning(self, "Warning", "Please select a credential to edit!")
            return
            
        username, password = current_item.text().split('/')
        dialog = CredentialDialog(self, username, password)
        if dialog.exec() == QtWidgets.QDialog.DialogCode.Accepted:
            new_username = dialog.username_input.text().strip()
            new_password = dialog.password_input.text().strip()
            if new_username and new_password:
                current_item.setText(f"{new_username}/{new_password}")

    def delete_credential(self):
        current_item = self.credentials_list.currentItem()
        if not current_item:
            QtWidgets.QMessageBox.warning(self, "Warning", "Please select a credential to delete!")
            return
            
        reply = QtWidgets.QMessageBox.question(
            self, 'Delete Credential',
            f'Are you sure you want to delete credential {current_item.text()}?',
            QtWidgets.QMessageBox.StandardButton.Yes | QtWidgets.QMessageBox.StandardButton.No
        )
        
        if reply == QtWidgets.QMessageBox.StandardButton.Yes:
            self.credentials_list.takeItem(self.credentials_list.row(current_item))

    def create_styled_button(self, text, icon_path, color):
        button = QtWidgets.QPushButton(text)
        button.setIcon(QtGui.QIcon(icon_path))
        button.setIconSize(QtCore.QSize(16, 16))
        button.setStyleSheet(f"""
            QPushButton {{
                background-color: {color};
                color: white;
                border: none;
                border-radius: 8px;
                padding: 8px 12px;
                font-weight: bold;
                font-size: 11px;
            }}
            QPushButton:hover {{
                background-color: {self.adjust_color(color, 10)};
            }}
            QPushButton:pressed {{
                background-color: {self.adjust_color(color, -10)};
                padding-left: 14px;
                padding-top: 10px;
            }}
        """)
        return button

    def adjust_color(self, hex_color, amount):
        hex_color = hex_color.lstrip('#')
        r, g, b = int(hex_color[0:2], 16), int(hex_color[2:4], 16), int(hex_color[4:6], 16)
        r = max(0, min(255, r + amount))
        g = max(0, min(255, g + amount))
        b = max(0, min(255, b + amount))
        return f'#{r:02x}{g:02x}{b:02x}'

class CredentialDialog(QtWidgets.QDialog):
    def __init__(self, parent=None, username="", password=""):
        super().__init__(parent)
        self.setWindowTitle("Credential")
        self.setModal(True)
        
        layout = QtWidgets.QVBoxLayout(self)
        
        form_layout = QtWidgets.QFormLayout()
        
        self.username_input = QtWidgets.QLineEdit(username)
        self.password_input = QtWidgets.QLineEdit(password)
        self.password_input.setEchoMode(QtWidgets.QLineEdit.EchoMode.Password)
        
        form_layout.addRow("Username:", self.username_input)
        form_layout.addRow("Password:", self.password_input)
        
        layout.addLayout(form_layout)
        
        buttons = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.StandardButton.Ok | 
            QtWidgets.QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
