import sys
import os
import pandas as pd
import glob
import subprocess
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
                             QPushButton, QLabel, QFileDialog, QTextEdit, QMessageBox,
                             QFrame, QSizePolicy, QScrollArea, QTabWidget, QTableWidget,
                             QTableWidgetItem, QHeaderView, QProgressBar, QGraphicsDropShadowEffect)
from PyQt6.QtGui import QFont, QColor, QPalette, QScreen, QIcon
from PyQt6.QtCore import Qt, QSize, QTimer

from openpyxl import Workbook
from openpyxl.styles import PatternFill
from openpyxl.utils import get_column_letter

# Thêm import để đọc version information từ native DLL
import ctypes
from ctypes import wintypes

def get_script_dir():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    else:
        return os.path.dirname(os.path.realpath(__file__))

script_dir = get_script_dir()

class DLLVersionInfo:
    def __init__(self):
        # Load version.dll
        self.version_dll = ctypes.WinDLL('version.dll', use_last_error=True)
        
        # Define Windows API functions từ version.dll
        self.version_dll.GetFileVersionInfoSizeW.argtypes = [wintypes.LPCWSTR, wintypes.LPDWORD]
        self.version_dll.GetFileVersionInfoSizeW.restype = wintypes.DWORD
        
        self.version_dll.GetFileVersionInfoW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, wintypes.LPVOID]
        self.version_dll.GetFileVersionInfoW.restype = wintypes.BOOL
        
        self.version_dll.VerQueryValueW.argtypes = [wintypes.LPCVOID, wintypes.LPCWSTR, ctypes.POINTER(ctypes.c_void_p), ctypes.POINTER(wintypes.UINT)]
        self.version_dll.VerQueryValueW.restype = wintypes.BOOL

    def get_dll_properties(self, dll_path):
        """Lấy các properties từ native DLL file"""
        properties = {}
        
        try:
            # Get file version info size
            dummy = wintypes.DWORD()
            info_size = self.version_dll.GetFileVersionInfoSizeW(dll_path, ctypes.byref(dummy))
            if info_size == 0:
                return self.get_fallback_properties(dll_path)
            
            # Allocate buffer for version info
            buffer = ctypes.create_string_buffer(info_size)
            
            # Get version info
            if not self.version_dll.GetFileVersionInfoW(dll_path, 0, info_size, buffer):
                return self.get_fallback_properties(dll_path)
            
            # Get fixed file info
            fixed_info_ptr = ctypes.c_void_p()
            fixed_info_len = wintypes.UINT()
            
            if self.version_dll.VerQueryValueW(buffer, '\\', ctypes.byref(fixed_info_ptr), ctypes.byref(fixed_info_len)):
                class VS_FIXEDFILEINFO(ctypes.Structure):
                    _fields_ = [
                        ('dwSignature', wintypes.DWORD),
                        ('dwStrucVersion', wintypes.DWORD),
                        ('dwFileVersionMS', wintypes.DWORD),
                        ('dwFileVersionLS', wintypes.DWORD),
                        ('dwProductVersionMS', wintypes.DWORD),
                        ('dwProductVersionLS', wintypes.DWORD),
                        ('dwFileFlagsMask', wintypes.DWORD),
                        ('dwFileFlags', wintypes.DWORD),
                        ('dwFileOS', wintypes.DWORD),
                        ('dwFileType', wintypes.DWORD),
                        ('dwFileSubtype', wintypes.DWORD),
                        ('dwFileDateMS', wintypes.DWORD),
                        ('dwFileDateLS', wintypes.DWORD),
                    ]
                
                fixed_info = ctypes.cast(fixed_info_ptr, ctypes.POINTER(VS_FIXEDFILEINFO)).contents
                
                # Extract version numbers
                file_version_hi = fixed_info.dwFileVersionMS >> 16
                file_version_lo = fixed_info.dwFileVersionMS & 0xFFFF
                file_version_build = fixed_info.dwFileVersionLS >> 16
                file_version_rev = fixed_info.dwFileVersionLS & 0xFFFF
                properties['FileVersion'] = f"{file_version_hi}.{file_version_lo}.{file_version_build}.{file_version_rev}"
                
                product_version_hi = fixed_info.dwProductVersionMS >> 16
                product_version_lo = fixed_info.dwProductVersionMS & 0xFFFF
                product_version_build = fixed_info.dwProductVersionLS >> 16
                product_version_rev = fixed_info.dwProductVersionLS & 0xFFFF
                properties['ProductVersion'] = f"{product_version_hi}.{product_version_lo}.{product_version_build}.{product_version_rev}"
            
            # Get string file info
            string_info_ptr = ctypes.c_void_p()
            string_info_len = wintypes.UINT()
            
            # Try different language codes (English and Korean)
            lang_codes = ['040904B0', '041204B0']  # English, Korean
            
            for lang_code in lang_codes:
                query_path = f'\\StringFileInfo\\{lang_code}\\'
                
                # Get all string properties
                string_properties = [
                    'FileDescription', 'FileVersion', 'InternalName', 'LegalCopyright',
                    'OriginalFilename', 'ProductName', 'ProductVersion', 'CompanyName',
                    'LegalTrademarks', 'PrivateBuild', 'SpecialBuild', 'Comments'
                ]
                
                for prop in string_properties:
                    prop_ptr = ctypes.c_void_p()
                    prop_len = wintypes.UINT()
                    
                    if self.version_dll.VerQueryValueW(buffer, query_path + prop, 
                                                     ctypes.byref(prop_ptr), ctypes.byref(prop_len)):
                        value = ctypes.wstring_at(prop_ptr, prop_len.value - 1)
                        if value and prop not in properties:
                            properties[prop] = value
            
            # Get file size and date
            self.add_file_metadata(dll_path, properties)
            
        except Exception as e:
            print(f"Error reading DLL properties: {e}")
            return self.get_fallback_properties(dll_path)
        
        return properties

    def get_fallback_properties(self, dll_path):
        """Fallback method nếu không đọc được version info"""
        properties = {}
        try:
            # Lấy thông tin cơ bản về file
            self.add_file_metadata(dll_path, properties)
            
            # Thêm các properties mặc định
            properties['Error'] = 'Could not read version information'
            
        except Exception as e:
            print(f"Error in fallback method: {e}")
            
        return properties

    def add_file_metadata(self, dll_path, properties):
        """Thêm metadata về file"""
        try:
            file_stats = os.stat(dll_path)
            properties['FileSize'] = f"{file_stats.st_size / 1024:.0f} KB"
            properties['DateModified'] = pd.to_datetime(file_stats.st_mtime, unit='s').strftime('%Y-%m-%d %H:%M:%S')
        except Exception as e:
            print(f"Error getting file metadata: {e}")

class MainWindow(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent_window = parent # Store reference to the parent window
        
        # Softer, eye-friendly color palette
        self.colors = {
            "primary": "#5B6CC3",      # Softer indigo
            "primary_light": "#7E8EE0", # Lighter indigo
            "secondary": "#4A9FCB",    # Softer sky blue
            "accent": "#8A7BC8",       # Softer violet
            "light": "#F5F7FA",        # Softer light background
            "light_card": "#FFFFFF",   # Card background
            "dark": "#2D3748",         # Softer dark text
            "medium": "#718096",       # Softer medium text
            "border": "#E2E8F0",       # Border color
            "success": "#48BB78",      # Softer green
            "warning": "#ED8936",      # Softer amber
            "error": "#F56565",        # Softer red
            "background": "#F1F5F9",   # Main background
        }

        self.setWindowTitle("DLL Properties Comparison Tool")
        self.setGeometry(0, 0, 1000, 800)
        self.setStyleSheet(f"""
            QMainWindow {{
                background-color: {self.colors['background']};
                color: {self.colors['dark']};
                font-family: 'Segoe UI', 'Roboto', sans-serif;
            }}
            QLabel {{
                color: {self.colors['dark']};
            }}
        """)

        self.template_file_path = ""
        self.input_directory = ""
        self.export_file_path = ""
        self.differences = {}
        self.total_files = 0
        self.processed_files = 0
        self.version_reader = DLLVersionInfo()

        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.layout = QVBoxLayout(self.central_widget)
        self.layout.setSpacing(10)
        self.layout.setContentsMargins(15, 15, 15, 15)

        self.setup_ui()
        self.center_on_screen()

    def closeEvent(self, event):
        if self.parent_window:
            self.parent_window.remove_blur()
        super().closeEvent(event)

    def setup_ui(self):
        # Header
        header_label = QLabel("DLL Properties Comparison Tool")
        header_label.setStyleSheet("font-size: 20px; font-weight: bold; color: #2c3e50; margin-bottom: 10px;")
        header_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.layout.addWidget(header_label)

        # File selection area
        file_selection_frame = QFrame()
        file_selection_frame.setStyleSheet(f"""
            background-color: {self.colors['light_card']};
            border-radius: 14px;
            border: 1px solid {self.colors['border']};
        """)
        file_selection_frame.setGraphicsEffect(self.create_card_shadow())
        file_selection_layout = QVBoxLayout(file_selection_frame)
        file_selection_layout.setSpacing(8)

        # Input directory selection
        input_layout = QHBoxLayout()
        input_layout.setSpacing(10)
        lbl_input = QLabel("Input Folder:")
        lbl_input.setStyleSheet(f"font-weight: bold; color: {self.colors['dark']};")
        lbl_input.setFixedWidth(150)
        self.lbl_input_directory = QLabel("No folder selected")
        self.lbl_input_directory.setStyleSheet(f"color: {self.colors['medium']};")
        self.lbl_input_directory.setWordWrap(True)
        input_layout.addWidget(lbl_input)
        input_layout.addWidget(self.lbl_input_directory, 1)
        
        btn_select_input = self.create_modern_button("Select", ":/icons/folder.png", self.colors['primary'])
        btn_select_input.setFixedWidth(100)
        btn_select_input.clicked.connect(self.select_input_directory)
        # btn_select_input.setFixedWidth(80) # Removed as create_modern_button sets size
        input_layout.addWidget(btn_select_input)
        file_selection_layout.addLayout(input_layout)

        # Template file selection
        template_layout = QHBoxLayout()
        template_layout.setSpacing(10)
        lbl_template = QLabel("Template DLL File:")
        lbl_template.setStyleSheet(f"font-weight: bold; color: {self.colors['dark']};")
        lbl_template.setFixedWidth(150)
        self.lbl_template_path = QLabel("No template selected")
        self.lbl_template_path.setStyleSheet(f"color: {self.colors['medium']};")
        self.lbl_template_path.setWordWrap(True)
        template_layout.addWidget(lbl_template)
        template_layout.addWidget(self.lbl_template_path, 1)
        
        btn_select_template = self.create_modern_button("Select", ":/icons/file.png", self.colors['secondary'])
        btn_select_template.setFixedWidth(100)
        btn_select_template.clicked.connect(self.select_template)
        # btn_select_template.setFixedWidth(80) # Removed as create_modern_button sets size
        template_layout.addWidget(btn_select_template)
        file_selection_layout.addLayout(template_layout)

        self.layout.addWidget(file_selection_frame)

        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setTextVisible(True)
        self.progress_bar.setStyleSheet(f"""
            QProgressBar {{
                height: 25px;
                background-color: {self.colors['light']};
                border: 1px solid {self.colors['border']};
                border-radius: 8px;
                text-align: center;
                margin: 0px;
                padding: 0px;
                color: {self.colors['dark']};
                font-weight: bold;
            }}
            QProgressBar::chunk {{
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                          stop:0 {self.colors['primary_light']}, stop:1 {self.colors['primary']});
                border-radius: 8px;
            }}
        """)
        self.layout.addWidget(self.progress_bar)

        # Action buttons
        button_layout = QHBoxLayout()
        button_layout.setSpacing(10)

        self.btn_compare = self.create_modern_button("Compare Files", ":/icons/compare.png", self.colors['success'])
        self.btn_compare.clicked.connect(self.start_comparison)
        button_layout.addWidget(self.btn_compare)

        self.btn_export = self.create_modern_button("Export to Excel", ":/icons/file.png", self.colors['accent']) # Changed to accent color
        self.btn_export.clicked.connect(self.export_excel)
        self.btn_export.setEnabled(False)
        button_layout.addWidget(self.btn_export)

        self.btn_clear = self.create_modern_button("Clear", ":/icons/delete.png", self.colors['error'])
        self.btn_clear.clicked.connect(self.clear_all)
        button_layout.addWidget(self.btn_clear)

        self.layout.addLayout(button_layout)

        # Results tabs
        self.tabs = QTabWidget()
        self.tabs.setStyleSheet(f"""
            QTabWidget::pane {{
                background-color: {self.colors['light_card']};
                border-radius: 12px;
                border: 1px solid {self.colors['border']};
                padding: 10px;
            }}
            QTabBar::tab {{
                background: {self.colors['light']};
                border: 1px solid {self.colors['border']};
                border-bottom-color: {self.colors['border']};
                border-top-left-radius: 8px;
                border-top-right-radius: 8px;
                min-width: 8ex;
                padding: 8px 15px;
                color: {self.colors['dark']};
                font-weight: 500;
            }}
            QTabBar::tab:selected {{
                background: {self.colors['light_card']};
                border-bottom-color: {self.colors['light_card']};
                color: {self.colors['primary']};
                font-weight: bold;
            }}
            QTabBar::tab:hover {{
                background: {self.colors['light']}a0;
            }}
        """)
        self.tabs.setGraphicsEffect(self.create_card_shadow())
        self.layout.addWidget(self.tabs, 1)

        # Log tab
        self.log_tab = QWidget()
        log_layout = QVBoxLayout(self.log_tab)
        
        self.log_area = QTextEdit()
        self.log_area.setReadOnly(True)
        self.log_area.setFont(QFont("Segoe UI", 10))
        self.log_area.setStyleSheet(f"""
            QTextEdit {{
                background-color: {self.colors['light']};
                border-radius: 8px;
                padding: 10px;
                font-family: 'Consolas', monospace;
                font-size: 12px;
                color: {self.colors['dark']};
                border: 1px solid {self.colors['border']};
            }}
        """)
        log_layout.addWidget(self.log_area)
        
        self.tabs.addTab(self.log_tab, "Log")

        # Differences tab
        self.diff_tab = QWidget()
        diff_layout = QVBoxLayout(self.diff_tab)
        
        self.diff_table = QTableWidget()
        self.diff_table.setColumnCount(5)
        self.diff_table.setHorizontalHeaderLabels(["File", "Property", "Template Value", "File Value", "Status"])
        self.diff_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.diff_table.verticalHeader().setVisible(False)
        self.diff_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.diff_table.setStyleSheet(f"""
            QTableWidget {{
                background-color: {self.colors['light_card']};
                border: 1px solid {self.colors['border']};
                border-radius: 8px;
                gridline-color: {self.colors['border']};
                selection-background-color: {self.colors['primary_light']}a0;
                selection-color: white;
            }}
            QHeaderView::section {{
                background-color: {self.colors['primary']};
                color: white;
                padding: 8px;
                border: 1px solid {self.colors['primary_light']};
                font-weight: bold;
                border-top-left-radius: 8px; /* For the very first cell */
                border-top-right-radius: 8px; /* For the very last cell */
            }}
            QTableWidget::item {{
                padding: 5px;
                border-bottom: 1px solid {self.colors['border']};
                color: {self.colors['dark']};
            }}
        """)
        diff_layout.addWidget(self.diff_table)
        
        self.tabs.addTab(self.diff_tab, "Differences")

        # Status bar
        self.status_bar = QLabel()
        self.status_bar.setStyleSheet(f"color: {self.colors['medium']}; font-size: 12px; border-top: 1px solid {self.colors['border']}; padding-top: 5px;")
        self.layout.addWidget(self.status_bar)

        # Author label
        author_label = QLabel("Author: nguyenvanvuong1")
        author_label.setStyleSheet(f"font-size: 12px; color: {self.colors['medium']};")
        author_label.setAlignment(Qt.AlignmentFlag.AlignRight)
        self.layout.addWidget(author_label)

    def update_status(self, message):
        self.status_bar.setText(message)

    def log_message(self, message, message_type="info"):
        if message_type == "error":
            colored_message = f'<span style="color: {self.colors['error']};">{message}</span>'
        elif message_type == "warning":
            colored_message = f'<span style="color: {self.colors['warning']};">{message}</span>'
        elif message_type == "success":
            colored_message = f'<span style="color: {self.colors['success']};">{message}</span>'
        else:
            colored_message = message
            
        self.log_area.append(colored_message)
        self.log_area.verticalScrollBar().setValue(self.log_area.verticalScrollBar().maximum())

    def clear_all(self):
        self.log_area.clear()
        self.diff_table.setRowCount(0)
        self.differences = {}
        self.btn_export.setEnabled(False)
        self.progress_bar.setValue(0)
        self.update_status("Ready")

    def select_input_directory(self):
        directory = QFileDialog.getExistingDirectory(self, "Select Input Directory")
        if directory:
            self.input_directory = directory
            self.lbl_input_directory.setText(directory)
            self.log_message(f"Selected input directory: {directory}")
            self.update_status(f"Input directory: {directory}")

    def select_template(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Select Template DLL File", "", "DLL files (*.dll)")
        if file_path:
            self.template_file_path = file_path
            self.lbl_template_path.setText(os.path.basename(file_path))
            self.log_message(f"Selected template file: {file_path}")
            self.update_status(f"Template: {os.path.basename(file_path)}")

    def get_dll_properties(self, dll_path):
        """Lấy các properties từ file DLL sử dụng Windows API"""
        return self.version_reader.get_dll_properties(dll_path)

    def start_comparison(self):
        if not self.template_file_path:
            self.log_message("Error: Please select a template DLL file first!", "error")
            QMessageBox.critical(self, "Error", "Please select a template DLL file first!")
            return
        
        if not self.input_directory:
            self.log_message("Error: Please select an input directory first!", "error")
            QMessageBox.critical(self, "Error", "Please select an input directory first!")
            return

        self.clear_all()
        self.log_message("Starting DLL properties comparison...")
        self.update_status("Comparing files...")
        
        # Count total files to process
        self.total_files = len([f for f in os.listdir(self.input_directory) if f.lower().endswith('.dll')])
        self.processed_files = 0
        
        if self.total_files == 0:
            self.log_message("No DLL files found in input directory", "warning")
            return
            
        # Get template properties first
        self.template_properties = self.get_dll_properties(self.template_file_path)
        if not self.template_properties:
            self.log_message("Error: Could not read properties from template DLL", "error")
            QMessageBox.critical(self, "Error", "Could not read properties from template DLL file!")
            return
            
        self.log_message(f"Template properties loaded successfully")
        self.log_message(f"Found {len(self.template_properties)} properties in template")
        
        # Start comparison with progress updates
        QTimer.singleShot(100, self.compare_next_file)

    def compare_next_file(self):
        if self.processed_files >= self.total_files:
            self.finish_comparison()
            return
            
        files = [f for f in os.listdir(self.input_directory) if f.lower().endswith('.dll')]
        if self.processed_files >= len(files):
            self.finish_comparison()
            return
            
        filename = files[self.processed_files]
        self.compare_single_file(filename)
        self.processed_files += 1
        
        # Update progress
        progress = int((self.processed_files / self.total_files) * 100)
        self.progress_bar.setValue(progress)
        self.update_status(f"Processing {filename} ({self.processed_files}/{self.total_files})")
        
        # Continue with next file
        QTimer.singleShot(10, self.compare_next_file)

    def compare_single_file(self, filename):
        file_path = os.path.join(self.input_directory, filename)
        differences = []

        # Get properties from current DLL file
        file_properties = self.get_dll_properties(file_path)
        if not file_properties:
            self.log_message(f"Warning: Could not read properties from {filename}", "warning")
            return

        # Compare each property with template (bỏ qua các property không cần thiết)
        for prop_name, template_value in self.template_properties.items():
            # Bỏ qua việc kiểm tra FileName vì mỗi file có tên khác nhau
            if prop_name in ['FileName', 'Error']:
                continue
                
            file_value = file_properties.get(prop_name, "MISSING")
            
            if file_value != template_value:
                differences.append((prop_name, template_value, file_value))
        
        if differences:
            self.differences[filename] = differences
            self.log_message(f"Found differences in {filename}: {len(differences)} properties differ", "warning")

    def finish_comparison(self):
        self.progress_bar.setValue(100)
        
        if self.differences:
            diff_count = len(self.differences)
            
            self.log_message(f"Comparison complete. Found differences in {diff_count} files.", "warning")
            
            self.populate_differences_table()
            self.btn_export.setEnabled(True)
            self.tabs.setCurrentIndex(1)  # Switch to differences tab
            
            # Show summary message
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Icon.Warning)
            msg.setWindowTitle("Comparison Results")
            msg.setText(f"Found differences in {diff_count} files")
            msg.exec()
        else:
            self.log_message("All DLL files have matching properties with the template", "success")
            QMessageBox.information(self, "Comparison Complete", "All DLL files have matching properties with the template.")

        self.update_status("Comparison complete")

    def populate_differences_table(self):
        self.diff_table.setRowCount(0)
        row = 0
        
        # Add differences for each file
        for filename, file_diffs in self.differences.items():
            for diff in file_diffs:
                prop_name, template_value, file_value = diff
                
                self.diff_table.insertRow(row)
                
                # File name
                file_item = QTableWidgetItem(filename)
                self.diff_table.setItem(row, 0, file_item)
                
                # Property name
                prop_item = QTableWidgetItem(prop_name)
                self.diff_table.setItem(row, 1, prop_item)
                
                # Template value
                template_item = QTableWidgetItem(str(template_value) if template_value is not None else "")
                self.diff_table.setItem(row, 2, template_item)
                
                # File value
                file_val_item = QTableWidgetItem(str(file_value) if file_value is not None else "MISSING")
                self.diff_table.setItem(row, 3, file_val_item)
                
                # Status
                status_item = QTableWidgetItem()
                if file_value == "MISSING":
                    status_item.setText("MISSING")
                    file_val_item.setBackground(QColor(255, 204, 203))  # Light red for missing
                    status_item.setBackground(QColor(255, 204, 203))
                else:
                    status_item.setText("DIFFERENT")
                    file_val_item.setBackground(QColor(255, 255, 153))  # Light yellow for different
                    status_item.setBackground(QColor(255, 255, 153))
                
                self.diff_table.setItem(row, 4, status_item)
                
                row += 1

        self.diff_table.resizeColumnsToContents()

    def export_excel(self):
        self.log_message("Exporting DLL properties to Excel...")
        self.update_status("Exporting to Excel...")
        self.progress_bar.setValue(0)

        OUTPUT_DIR_NAME = "Output"
        FILE_EXT = 'dll'

        cwd = get_script_dir()
        output_dir = os.path.join(cwd, OUTPUT_DIR_NAME)
        input_dir = self.input_directory

        os.makedirs(output_dir, exist_ok=True)

        # Get all DLL files including the template
        all_files = [self.template_file_path] if self.template_file_path else []
        all_files.extend(glob.glob(os.path.join(input_dir, f"*.{FILE_EXT}")))
        
        if not all_files:
            QMessageBox.warning(self, "Warning", "No DLL files found.")
            return

        # Prepare data and track progress
        data = {}
        total_files = len(all_files)
        processed_files = 0
        
        for dll_file in all_files:
            file_name = os.path.basename(dll_file)
            properties = self.get_dll_properties(dll_file)
            data[file_name] = properties
            
            processed_files += 1
            progress = int((processed_files / total_files) * 50)
            self.progress_bar.setValue(progress)
            QApplication.processEvents()

        # Get all unique property names (bỏ qua FileName và Error)
        all_properties = set()
        for properties in data.values():
            for prop_name in properties.keys():
                if prop_name not in ['FileName', 'Error']:
                    all_properties.add(prop_name)
        all_properties = sorted(all_properties)

        # Create workbook
        wb = Workbook()
        ws = wb.active
        ws.title = "DLL Properties"

        # Write headers
        ws.cell(row=1, column=1, value="Property")
        for col, file_name in enumerate(data.keys(), start=2):
            ws.cell(row=1, column=col, value=file_name)

        # Write data and highlight differences
        yellow_fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
        red_fill = PatternFill(start_color="FFCCCB", end_color="FFCCCB", fill_type="solid")
        
        template_name = os.path.basename(self.template_file_path) if self.template_file_path else list(data.keys())[0]
        
        for row_idx, prop_name in enumerate(all_properties, start=2):
            ws.cell(row=row_idx, column=1, value=prop_name)
            
            template_value = data[template_name].get(prop_name, "MISSING")
            
            for col_idx, file_name in enumerate(data.keys(), start=2):
                file_value = data[file_name].get(prop_name, "MISSING")
                cell = ws.cell(row=row_idx, column=col_idx, value=file_value)
                
                # Highlight differences
                if file_value != template_value:
                    if file_value == "MISSING":
                        cell.fill = red_fill
                    else:
                        cell.fill = yellow_fill
            
            # Update progress
            if row_idx % 2 == 0:
                progress = 50 + int((row_idx / (len(all_properties) + 2)) * 50)
                self.progress_bar.setValue(progress)
                QApplication.processEvents()

        # Auto-size columns
        for col in ws.columns:
            max_length = 0
            column = col[0].column_letter
            for cell in col:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column].width = adjusted_width

        # Save file
        self.export_file_path = os.path.join(output_dir, 'dll_properties.xlsx')
        try:
            wb.save(self.export_file_path)
            self.progress_bar.setValue(100)
            self.log_message(f"Successfully exported to {self.export_file_path}", "success")
            self.update_status(f"Exported to {os.path.basename(self.export_file_path)}")
            
            # Automatically open the exported file
            try:
                if os.name == 'nt':
                    os.startfile(self.export_file_path)
                else:
                    subprocess.call(['xdg-open', self.export_file_path])
            except Exception as e:
                self.log_message(f"Note: Could not automatically open file: {str(e)}", "warning")
                
        except Exception as e:
            self.log_message(f"Error exporting to Excel: {str(e)}", "error")
            QMessageBox.critical(self, "Export Error", f"Failed to export to Excel:\n{str(e)}")

    def center_on_screen(self):
        screen = QApplication.primaryScreen().availableGeometry()
        size = self.geometry()
        x = (screen.width() - size.width()) // 2
        y = (screen.height() - size.height()) // 2
        self.move(x, y)

    def create_card_shadow(self):
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(20)
        shadow.setXOffset(0)
        shadow.setYOffset(4)
        shadow.setColor(QColor(0, 0, 0, 20))
        return shadow

    def create_modern_button(self, text, icon_path, color):
        button = QPushButton(text)
        button.setIcon(QIcon(icon_path))
        button.setIconSize(QSize(22, 22))
        button.setMinimumHeight(42)
        button.setStyleSheet(f"""
            QPushButton {{
                background-color: {color};
                color: white;
                border: none;
                padding: 10px 18px;
                border-radius: 10px;
                font-weight: bold;
                font-size: 13px;
            }}
            QPushButton:hover {{
                background-color: {self.adjust_color(color, 15)};
            }}
            QPushButton:pressed {{
                background-color: {self.adjust_color(color, -15)};
                padding: 11px 18px 9px 18px;
            }}
            QPushButton:disabled {{
                background-color: {self.colors['border']};
                color: {self.colors['medium']};
            }}
        """)
        button.setGraphicsEffect(self.create_button_shadow(color))
        return button

    def adjust_color(self, color, amount):
        r = int(color[1:3], 16)
        g = int(color[3:5], 16)
        b = int(color[5:7], 16)
        r = max(0, min(255, r + amount))
        g = max(0, min(255, g + amount))
        b = max(0, min(255, b + amount))
        return f"#{r:02x}{g:02x}{b:02x}"
        
    def create_button_shadow(self, color):
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(15)
        shadow.setXOffset(0)
        shadow.setYOffset(5)
        shadow.setColor(QColor(color + "60"))
        return shadow

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    window = MainWindow()
    window.show()
    sys.exit(app.exec())