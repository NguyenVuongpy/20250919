import sys
import os
import glob
import pandas as pd
import openpyxl
from openpyxl.styles import PatternFill, Alignment, Border, Side
from PyQt6.QtWidgets import (QApplication, QMainWindow, QPushButton, QVBoxLayout, QHBoxLayout, 
                             QWidget, QFileDialog, QTextEdit, QLabel, QFrame, QMessageBox,
                             QDialog, QScrollArea, QTableWidget, QHeaderView, QTableWidgetItem,
                             QProgressBar,QGraphicsDropShadowEffect)
from PyQt6.QtGui import QColor, QFont, QPalette, QIcon
from PyQt6.QtCore import Qt, QSize
from PyQt6 import QtCore, QtGui, QtWidgets
from XML import *
import rc.icons

def get_script_dir():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    else:
        return os.path.dirname(os.path.realpath(__file__))

script_dir = get_script_dir()

class ComparisonResultDialog(QDialog):
    def __init__(self, df_result, different_params, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Comparison Results")
        self.setWindowIcon(QIcon(':/icons/app.png'))
        self.resize(1000, 700)
        
        # Main layout
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # Header
        header = QHBoxLayout()
        warning_icon = QLabel()
        warning_icon.setPixmap(QIcon(':/icons/warning').pixmap(32, 32))
        header.addWidget(warning_icon)
        title = QLabel("Differences Detected!")
        title.setStyleSheet("color: #dc3545; font-weight: bold; font-size: 16px;")
        header.addWidget(title)
        header.addStretch()
        layout.addLayout(header)
        
        # Create table
        self.table = QTableWidget()
        self.table.setRowCount(len(df_result))
        self.table.setColumnCount(len(different_params) + 1)
        
        # Set headers
        headers = ['File Name'] + different_params
        self.table.setHorizontalHeaderLabels(headers)
        
        # Simplified table style
        self.table.setStyleSheet("""
            QTableWidget {
                border: 1px solid #dee2e6;
                gridline-color: #dee2e6;
            }
            QTableWidget::item {
                padding: 8px;
            }
            QHeaderView::section {
                background-color: #aaaaaa;
                padding: 8px;
                border: 1px solid #dee2e6;
                font-weight: bold;
            }
        """)
        
        # Populate table with highlighting
        self.populate_table(df_result, different_params)
        
        # Add hover effect after populating
        self.table.setStyleSheet(self.table.styleSheet() + """
            QTableWidget::item:hover {
                background-color: #e8f0fe;
            }
        """)
        
        # Adjust table properties
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)  # Keep filename column fixed
        for col in range(1, len(different_params) + 1):
            self.table.horizontalHeader().setSectionResizeMode(col, QHeaderView.ResizeMode.ResizeToContents)  # Auto-resize other columns
        
        # Ensure both header and column adjust automatically
        self.table.resizeColumnsToContents()  # Resize column width based on contents
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)  # Resize header columns
        
        # Freeze first row and column (i.e., 'B4' in Excel)
        self.table.setSortingEnabled(True)

        # Hide vertical header (row numbers)
        self.table.verticalHeader().hide()
        
        # Freeze first column
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
        
        # Freeze first row (set the header as frozen)
        self.table.verticalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)

        # Wrap the table in a QScrollArea for horizontal scrolling
        scroll_area = QScrollArea()
        scroll_area.setWidget(self.table)
        scroll_area.setWidgetResizable(True)
        
        # Add scroll area to layout with spacing
        layout.addSpacing(10)
        layout.addWidget(scroll_area)
        layout.addSpacing(10)
        
        # Tip label with enhanced style
        tip_label = QLabel('💡 Tip: Click the "Create Highlight File" button for complete details in Excel')
        tip_label.setStyleSheet("""
            color: #666;
            background-color: #e9ecef;
            padding: 10px;
            border-radius: 4px;
            margin: 10px 0;
            font-style: italic;
        """)
        tip_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(tip_label)
        
        # OK button with enhanced style
        button_layout = QHBoxLayout()
        ok_button = QPushButton("OK")
        ok_button.setFixedWidth(100)
        ok_button.setStyleSheet("""
            QPushButton {
                background-color: #007bff;
                color: white;
                border: none;
                padding: 8px;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #0056b3;
            }
            QPushButton:pressed {
                background-color: #004085;
            }
        """)
        ok_button.clicked.connect(self.accept)
        button_layout.addStretch()
        button_layout.addWidget(ok_button)
        layout.addLayout(button_layout)

    def populate_table(self, df_result, different_params):
        # Add rows
        for row_idx, (_, row_data) in enumerate(df_result.iterrows()):
            filename = row_data['Checked XML File']
            
            # Add filename with warning icon if it's in identical sequences
            filename_item = QTableWidgetItem()
            filename_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            filename_item.setFlags(filename_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            
            # Kiểm tra xem file có nằm trong nhóm file giống nhau không
            is_identical = False
            for group in self.parent().identical_sequences.values():
                if filename in group:
                    is_identical = True
                    break
            
            # Thêm icon cảnh báo nếu file có nội dung giống file khác
            if is_identical:
                filename_item.setText(f"⚠️ {filename}")
                filename_item.setBackground(QColor('#FFF3CD'))  # Light yellow background
                filename_item.setToolTip("This sequence has identical content with other sequence(s)")
            else:
                filename_item.setText(filename)
                
            self.table.setItem(row_idx, 0, filename_item)

            # Add parameter values
            for col_idx, param in enumerate(different_params):
                current_value = str(row_data[param])
                value_item = QTableWidgetItem(current_value)
                value_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                value_item.setFlags(value_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                
                # Highlight cells with different values
                most_common = df_result[param].mode().iloc[0]
                if current_value != most_common:
                    brush = QColor('#FFD700')
                    value_item.setBackground(brush)
                
                self.table.setItem(row_idx, col_idx + 1, value_item)

class IdenticalResultDialog(QDialog):
    def __init__(self, df_result, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Comparison Results")
        self.setWindowIcon(QIcon(':/icons/app.png'))
        self.resize(600, 400)
        
        # Main layout
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        # Header
        header = QHBoxLayout()
        success_icon = QLabel()
        success_icon.setPixmap(QIcon(':/icons/success').pixmap(32, 32))
        header.addWidget(success_icon)
        
        title = QLabel("All Settings Are Identical!")
        title.setStyleSheet("""
            color: #28a745;
            font-weight: bold;
            font-size: 16px;
        """)
        header.addWidget(title)
        header.addStretch()
        layout.addLayout(header)
        
        # Description
        desc_label = QLabel("All settings in the following sequences are identical:")
        desc_label.setStyleSheet("color: #666;")
        layout.addWidget(desc_label)
        
        # File list in a scroll area
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("""
            QScrollArea {
                border: 1px solid #dee2e6;
                background-color: #f8f9fa;
                border-radius: 4px;
            }
        """)
        
        file_list_widget = QWidget()
        file_list_layout = QVBoxLayout(file_list_widget)
        file_list_layout.setSpacing(8)
        
        # Add files to the list
        for filename in df_result['Checked XML File']:
            file_label = QLabel(f"• {filename}")
            file_label.setStyleSheet("""
                padding: 4px;
                color: #333;
            """)
            file_list_layout.addWidget(file_label)
        
        file_list_layout.addStretch()
        scroll.setWidget(file_list_widget)
        layout.addWidget(scroll)
        
        # Tip
        tip_label = QLabel('💡 You can check the detailed comparison in the generated Excel file.')
        tip_label.setStyleSheet("""
            color: #666;
            font-style: italic;
            background-color: #e9ecef;
            padding: 10px;
            border-radius: 4px;
        """)
        tip_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(tip_label)
        
        # OK button
        button_layout = QHBoxLayout()
        ok_button = QPushButton("OK")
        ok_button.setFixedWidth(100)
        ok_button.setStyleSheet("""
            QPushButton {
                background-color: #28a745;
                color: white;
                border: none;
                padding: 8px;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #218838;
            }
            QPushButton:pressed {
                background-color: #1e7e34;
            }
        """)
        ok_button.clicked.connect(self.accept)
        button_layout.addStretch()
        button_layout.addWidget(ok_button)
        layout.addLayout(button_layout)

class XMLComparisonApp(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent_window = parent # Store reference to the parent window
        self.setWindowIcon(QIcon(':/icons/app.png'))
        self.identical_sequences = {}  # Thêm biến instance
        self.initUI()

    def closeEvent(self, event):
        if self.parent_window:
            self.parent_window.remove_blur()
        super().closeEvent(event)

    def initUI(self):
        self.setWindowTitle('XML Comparison Tool')
        self.resize(700, 700)

        main_widget = QWidget()
        self.setCentralWidget(main_widget)

        layout = QVBoxLayout()
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)

        # Title
        title_frame = QFrame()
        title_frame.setFixedHeight(110)  # Tăng chiều cao
        title_frame.setStyleSheet("""
            QFrame {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                                          stop:0 #1f6692, stop:0.5 #3498db, stop:1 #5dade2);
                border-radius: 15px;
                margin: 5px;
            }
        """)

        # Thêm outer glow effect cho header
        header_shadow = QGraphicsDropShadowEffect()
        header_shadow.setBlurRadius(40)
        header_shadow.setXOffset(0)
        header_shadow.setYOffset(6)
        header_shadow.setColor(QColor(52, 152, 219, 120))
        title_frame.setGraphicsEffect(header_shadow)

        title_layout = QHBoxLayout(title_frame)
        title_layout.setContentsMargins(30, 15, 30, 15)
        title_layout.setSpacing(20)

        # Icon trong header với đổ bóng
        app_icon = QtWidgets.QPushButton()
        app_icon.setFixedSize(70, 70)
        app_icon.setCursor(QtGui.QCursor(QtCore.Qt.CursorShape.PointingHandCursor))
        app_icon.setStyleSheet("""
            QPushButton {
                background: transparent;
                border: none;
                border-radius: 45px;
                padding: 10px;
            }
        """)

        # Tạo shadow effect cho icon
        icon_shadow = QGraphicsDropShadowEffect()
        icon_shadow.setBlurRadius(15)
        icon_shadow.setXOffset(3)
        icon_shadow.setYOffset(3)
        icon_shadow.setColor(QColor(0, 0, 0, 80))
        app_icon.setGraphicsEffect(icon_shadow)

        # Set icon với kích thước lớn hơn
        icon_pixmap = QtGui.QIcon(':/icons/app.png')
        app_icon.setIcon(icon_pixmap)
        app_icon.setIconSize(QtCore.QSize(70, 70))

        title_layout.addWidget(app_icon)

        # Text container
        text_container = QWidget()
        text_container.setStyleSheet("""
            QWidget {
                background: transparent;
            }
        """)
        text_layout = QVBoxLayout(text_container)
        text_layout.setSpacing(5)

        title_label = QLabel('XML Comparison Sequence')
        title_label.setAlignment(Qt.AlignmentFlag.AlignLeft)
        title_label.setFont(QFont("Segoe UI", 16, QFont.Weight.Bold))
        title_label.setStyleSheet("""
            color: white;
            padding: 0;
            margin: 0;
            letter-spacing: 1px;
        """)

        subtitle_label = QLabel('Advanced XML Analysis Tool')
        subtitle_label.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
        subtitle_label.setStyleSheet("""
            color: rgba(255, 255, 255, 0.95);
            margin-top: 0px;
            padding: 0;
            letter-spacing: 0.5px;
        """)

        text_layout.addWidget(title_label)
        text_layout.addWidget(subtitle_label)
        title_layout.addWidget(text_container)

        title_layout.addStretch()

        # Version label
        version_label = QLabel("⚡ v2.0 \n 2025")
        version_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignBottom)
        version_label.setFont(QFont("Segoe UI", 9))
        version_label.setStyleSheet("""
            color: rgba(255, 255, 255, 0.9);
            background: rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            padding: 8px;
        """)
        title_layout.addWidget(version_label)

        layout.addWidget(title_frame)

        # Buttons
        button_layout = QHBoxLayout()
        button_layout.setSpacing(20)
        button_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.select_input_btn = self.createStyledButton('Select Input Folder')
        self.select_input_btn.setIcon(QIcon(':/icons/folder'))
        self.select_input_btn.setIconSize(QSize(24, 24))
        self.select_input_btn.clicked.connect(self.select_input_folder)
        self.select_input_btn.setToolTip(
            "Select folder containing sequence files to compare\n"
            "- Accepts .seqxc files\n"
            "- Will check for identical sequence content"
        )

        self.select_xpath_btn = self.createStyledButton('Select XPath File')
        self.select_xpath_btn.setIcon(QIcon(':/icons/file'))
        self.select_xpath_btn.setIconSize(QSize(24, 24))
        self.select_xpath_btn.clicked.connect(self.select_xpath_file)
        self.select_xpath_btn.setToolTip(
            "Select XPath List file (.csv) containing nodes to compare\n"
            "- Must be CSV format\n"
            "- Structure: 2 columns (Parameter Name, XML Node Path)"
        )

        self.run_comparison_btn = self.createStyledButton('Run Comparison')
        self.run_comparison_btn.setIcon(QIcon(':/icons/compare'))
        self.run_comparison_btn.setIconSize(QSize(24, 24))
        self.run_comparison_btn.clicked.connect(self.run_comparison)
        self.run_comparison_btn.setToolTip(
            "Start sequence comparison process\n"
            "- Checks for identical sequence content\n"
            "- Compares parameter values between sequences\n"
            "- Shows warning for identical sequences\n"
            "- Highlights different parameter values"
        )

        button_layout.addWidget(self.select_input_btn)
        button_layout.addWidget(self.select_xpath_btn)
        button_layout.addWidget(self.run_comparison_btn)
        layout.addLayout(button_layout)

        # Status labels
        self.input_label = QLabel('Input Folder: Not selected')
        self.xpath_label = QLabel('XPath File: Not selected')
        self.input_label.setStyleSheet("""
            QLabel {
                color: #555;
                font-style: italic;
                padding: 5px;
                background: #f8f9fa;
                border-radius: 5px;
            }
        """)
        self.xpath_label.setStyleSheet("""
            QLabel {
                color: #555;
                font-style: italic;
                padding: 5px;
                background: #f8f9fa;
                border-radius: 5px;
            }
        """)
        layout.addWidget(self.input_label)
        layout.addWidget(self.xpath_label)

        # Result display
        self.result_display = QTextEdit()
        self.result_display.setReadOnly(True)
        self.result_display.setStyleSheet("""
            QTextEdit {
                background-color: #ffffff;
                border: 2px solid #e3e8f0;
                border-radius: 10px;
                padding: 15px;
                font-family: 'Consolas', 'Courier New', monospace;
                font-size: 13px;
                line-height: 1.4;
                color: #2c3e50;
            }
            QTextEdit:focus {
                border: 2px solid #3498db;
            }
        """)
        log_shadow = QGraphicsDropShadowEffect()
        log_shadow.setBlurRadius(20)
        log_shadow.setXOffset(0)
        log_shadow.setYOffset(2)
        log_shadow.setColor(QColor(0, 0, 0, 30))
        self.result_display.setGraphicsEffect(log_shadow)
        layout.addWidget(self.result_display)

        # Progress bar - Di chuyển xuống dưới result display
        self.progress_bar = QProgressBar()
        self.progress_bar.setFixedHeight(25)
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                background-color: #f8f9fa;
                border: none;
                border-radius: 8px;
                text-align: center;
                margin: 0px;
                padding: 0px;
            }
            QProgressBar::chunk {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                          stop:0 #7cc4ff, stop:1 #4da9ff);
                border-radius: 8px;
            }
            QProgressBar::text {
                color: #2c3e50;
                font-weight: bold;
                font-size: 12px;
            }
        """)
        self.progress_bar.setFormat("%p% - %v/%m")
        self.progress_bar.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.progress_bar.hide()  # Ẩn ban đầu
        layout.addWidget(self.progress_bar)

        # Output buttons
        output_buttons_layout = QHBoxLayout()
        output_buttons_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.create_highlight_btn = self.createStyledButton('Create Highlight File')
        self.create_highlight_btn.setIcon(QIcon(':/icons/highlight'))
        self.create_highlight_btn.setIconSize(QSize(24, 24))
        self.create_highlight_btn.clicked.connect(self.create_highlight_file)
        self.create_highlight_btn.setToolTip(
            "Create Excel file with highlighted differences\n"
            "- Adds warning icon (⚠️) for identical sequences\n"
            "- Highlights different parameter values in yellow\n"
            "- Gray header for better readability\n"
            "- File will be saved in Output folder"
        )

        self.open_output_btn = self.createStyledButton('Open Output Folder')
        self.open_output_btn.setIcon(QIcon(':/icons/open'))
        self.open_output_btn.setIconSize(QSize(24, 24))
        self.open_output_btn.clicked.connect(self.open_output_folder)
        self.open_output_btn.setToolTip(
            "Open folder containing result files\n"
            "- XML Reading Result.csv: Raw comparison data\n"
            "- Highlighted_Differences.xlsx: Excel file with visual indicators"
        )

        output_buttons_layout.addWidget(self.create_highlight_btn)
        output_buttons_layout.addWidget(self.open_output_btn)
        layout.addLayout(output_buttons_layout)

        # Author label
        author_label = QLabel('Author: nguyenvanvuong1')
        author_label.setAlignment(Qt.AlignmentFlag.AlignRight)
        author_label.setStyleSheet("""
            QLabel {
                color: #95a5a6;
                font-style: italic;
                padding: 5px;
                font-size: 12px;
            }
        """)
        layout.addWidget(author_label)

        main_widget.setLayout(layout)

        # Change the way to set background color
        self.setStyleSheet("background-color: #f5f5f5;")

    def createStyledButton(self, text):
        button = QPushButton(text)
        button.setStyleSheet("""
            QPushButton {
                color: #2c3e50;
                background-color: #ffffff;
                border: 2px solid #3498db;
                border-radius: 10px;
                font-weight: bold;
                font-size: 14px;
                min-width: 180px;
                max-width: 180px;
                min-height: 45px;
                max-height: 45px;
                padding-left: 12px;
                text-align: left;
                qproperty-iconSize: 24px 24px;
            }
            QPushButton:hover {
                background-color: #3498db;
                color: white;
                border: none;
            }
            QPushButton:pressed {
                background-color: #2980b9;
                color: white;
                border: none;
                padding-left: 14px;
                padding-top: 2px;
            }
            QPushButton:disabled {
                background-color: #bdc3c7;
                color: #7f8c8d;
                border: 2px solid #95a5a6;
            }
        """)
        button.setGraphicsEffect(self.create_shadow_effect())
        return button

    def select_input_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Select Input Folder")
        if folder:
            self.input_folder = folder
            self.input_label.setText(f'Input Folder: {folder}')

    def select_xpath_file(self):
        file, _ = QFileDialog.getOpenFileName(self, "Select XPath File", "", "CSV Files (*.csv)")
        if file:
            self.xpath_file = file
            self.xpath_label.setText(f'XPath File: {file}')

    def check_identical_sequences(self, file_list):
        """
        Kiểm tra các file sequence có nội dung giống nhau
        Args:
            file_list: Danh sách các file seqxc cần kiểm tra
        Returns:
            dict: Dictionary chứa các nhóm file có nội dung giống nhau
        """
        identical_groups = {}
        file_contents = {}
        
        # Đọc nội dung của tất cả các file
        for filename in file_list:
            with open(filename, 'r', encoding='utf-8') as f:
                content = f.read()
                file_contents[filename] = content
        
        # So sánh nội dung các file
        processed_files = set()
        current_group = 0
        
        for file1 in file_contents:
            if file1 in processed_files:
                continue
            
            identical_groups[current_group] = [file1]
            processed_files.add(file1)
            
            for file2 in file_contents:
                if file2 != file1 and file2 not in processed_files:
                    if file_contents[file1] == file_contents[file2]:
                        identical_groups[current_group].append(file2)
                        processed_files.add(file2)
            
            if len(identical_groups[current_group]) == 1:
                del identical_groups[current_group]
            else:
                current_group += 1
            
        return identical_groups


    def run_comparison(self):
        try:
            if not hasattr(self, 'input_folder') or not hasattr(self, 'xpath_file'):
                QMessageBox.warning(self, 
                                  "Missing Input",
                                  "Please select both input folder and XPath file.",
                                  QMessageBox.StandardButton.Ok)
                return

            # Tạo thư mục Output tại nơi chứa script
            script_dir = os.path.dirname(os.path.abspath(__file__))
            self.output_dir = os.path.join(script_dir, 'Output')
            os.makedirs(self.output_dir, exist_ok=True)

            # Lấy tên folder chứa file seqxc
            folder_name = os.path.basename(self.input_folder)
            self.result_file_prefix = f"{folder_name}_"

            self.result_display.clear()
            self.result_display.append("Starting comparison process...")
            
            # Hiển thị và reset progress bar
            self.progress_bar.show()
            self.progress_bar.setValue(0)
            QApplication.processEvents()

            # Lấy danh sách file XML
            os.chdir(self.input_folder)
            detect_read_filenames = [i for i in glob.glob('*.seqxc')]
            total_files = len(detect_read_filenames)

            if total_files == 0:
                QMessageBox.warning(self,
                                  "No Files Found",
                                  "No .seqxc files found in the selected folder.",
                                  QMessageBox.StandardButton.Ok)
                return

            # Kiểm tra các sequence giống nhau trước
            self.identical_sequences = self.check_identical_sequences(detect_read_filenames)
            
            if self.identical_sequences:
                warning_msg = "WARNING: Found sequences with identical content:\n\n"
                for group_id, files in self.identical_sequences.items():
                    warning_msg += f"Group {group_id + 1}:\n"
                    for file in files:
                        warning_msg += f"• {file}\n"
                    warning_msg += "These sequences may not have Calibration Settings configured!\n\n"
                
                self.result_display.append("\n" + "="*50)
                self.result_display.append(warning_msg)
                
                # Hiển thị message box cảnh báo
                QMessageBox.warning(self, 
                                  "Identical Sequences Detected",
                                  warning_msg,
                                  QMessageBox.StandardButton.Ok)

            self.result_display.append(f"\nFound {total_files} XML files to process.")
            
            # Đọc XPath list
            try:
                df_reading_nodes_list = pd.read_csv(self.xpath_file, index_col=None, sep=',', header=0)
                if len(df_reading_nodes_list.columns) != 2:
                    raise ValueError("XPath file must have exactly 2 columns (Parameter Name, XML Node Path)")
            except Exception as e:
                QMessageBox.critical(self,
                                   "XPath File Error",
                                   f"Error reading XPath file: {str(e)}\n\n"
                                   "Please make sure the file is a valid CSV with 2 columns:\n"
                                   "1. Parameter Name\n"
                                   "2. XML Node Path",
                                   QMessageBox.StandardButton.Ok)
                return

            df_list_results = []

            # Xử lý từng file và cập nhật tiến độ
            for idx, xmlfilename in enumerate(detect_read_filenames):
                try:
                    progress = int((idx / total_files) * 100)
                    self.progress_bar.setValue(progress)
                    self.progress_bar.setFormat(f"{progress}% - Processing: {xmlfilename}")
                    
                    # Highlight tên file nếu nó nằm trong danh sách file giống nhau
                    is_identical = False
                    for group in self.identical_sequences.values():
                        if xmlfilename in group:
                            is_identical = True
                            self.result_display.append(f"Processing file ({idx + 1}/{total_files}): {xmlfilename} ⚠️")
                            break
                        
                    if not is_identical:
                        self.result_display.append(f"Processing file ({idx + 1}/{total_files}): {xmlfilename}")
                    
                    QApplication.processEvents()

                    xmlfile = xmlGet(xmlfilename)
                    if not xmlfile:
                        error_msg = f"Error: Could not process {xmlfilename}"
                        self.result_display.append(error_msg)
                        QMessageBox.warning(self,
                                          "File Processing Error",
                                          error_msg,
                                          QMessageBox.StandardButton.Ok)
                        continue
                    
                    nodes_read_from_xmlfile = {'Checked XML File': xmlfilename}

                    # Đọc các node từ file
                    for _, list_row in df_reading_nodes_list.iterrows():
                        key = list_row.iloc[0]
                        node_path = list_row.iloc[1]
                        val = xmlReadXPath(xmlfile, node_path)
                        nodes_read_from_xmlfile[key] = val

                    if nodes_read_from_xmlfile:
                        df_list_results.append(nodes_read_from_xmlfile)

                except Exception as e:
                    error_msg = f"Error processing file {xmlfilename}: {str(e)}"
                    self.result_display.append(error_msg)
                    QMessageBox.warning(self,
                                      "File Processing Error",
                                      error_msg,
                                      QMessageBox.StandardButton.Ok)
                    continue

            if not df_list_results:
                QMessageBox.warning(self,
                                  "No Results",
                                  "No valid data was extracted from the XML files.",
                                  QMessageBox.StandardButton.Ok)
                return

            # Hoàn thành
            self.progress_bar.setValue(100)
            self.progress_bar.setFormat("100% - Processing completed!")
            self.result_display.append("\nComparison process completed!")
            QApplication.processEvents()

            self.df_final_result = pd.DataFrame(df_list_results)

            # So sánh và hiển thị kết quả
            self.different_params = []
            for column in self.df_final_result.columns:
                if column != 'Checked XML File':
                    # Kiểm tra nếu có nhiều hơn 1 giá trị khác nhau trong cột
                    if self.df_final_result[column].nunique() > 1:
                        self.different_params.append(column)

            # Hiển thị dialog kết quả
            if self.different_params:
                dialog = ComparisonResultDialog(self.df_final_result, self.different_params, self)
                dialog.exec()
            else:
                dialog = IdenticalResultDialog(self.df_final_result, self)
                dialog.exec()

            # Lưu kết quả và hiển thị các nút
            try:
                csv_file = os.path.join(self.output_dir, f'{self.result_file_prefix}XML Reading Result.csv')
                self.df_final_result.to_csv(csv_file, index=False)
                self.result_display.append(f"\nResults have been saved to: {csv_file}")
            except Exception as e:
                error_msg = f"Error saving results: {str(e)}"
                self.result_display.append(f"\n{error_msg}")
                QMessageBox.critical(self,
                                   "Save Error",
                                   error_msg,
                                   QMessageBox.StandardButton.Ok)

            # Ẩn thanh tiến độ khi hoàn thành
            self.progress_bar.hide()

            # Hiển thị các nút output
            self.create_highlight_btn.show()
            self.open_output_btn.show()

        except Exception as e:
            error_msg = f"An unexpected error occurred: {str(e)}"
            self.result_display.append(f"\n{error_msg}")
            QMessageBox.critical(self,
                               "Unexpected Error",
                               error_msg,
                               QMessageBox.StandardButton.Ok)
            self.progress_bar.hide()

    def create_highlight_file(self):
        try:
            if not hasattr(self, 'df_final_result') or not hasattr(self, 'different_params'):
                QMessageBox.warning(self,
                                  "No Data",
                                  "Please run the comparison first.",
                                  QMessageBox.StandardButton.Ok)
                return

            highlight_file = os.path.join(self.output_dir, f'{self.result_file_prefix}Highlighted_Differences.xlsx')
            
            # Use openpyxl for Excel file creation
            writer = pd.ExcelWriter(highlight_file, engine='openpyxl')
            self.df_final_result.to_excel(writer, index=False, sheet_name='Sheet1')
            
            workbook = writer.book
            worksheet = workbook['Sheet1']
            
            # Define cell styles
            highlight_fill = PatternFill(start_color='FFFF00', end_color='FFFF00', fill_type='solid')
            warning_fill = PatternFill(start_color='FFF3CD', end_color='FFF3CD', fill_type='solid')
            header_fill = PatternFill(start_color='aaaaaa', end_color='aaaaaa', fill_type='solid')
            center_alignment = Alignment(horizontal='center', vertical='center')
            thin_border = Border(
                left=Side(style='thin'),
                right=Side(style='thin'),
                top=Side(style='thin'),
                bottom=Side(style='thin')
            )
            
            # Apply basic formatting to all cells
            for row in worksheet.iter_rows(min_row=1, max_row=worksheet.max_row, 
                                         min_col=1, max_col=worksheet.max_column):
                for cell in row:
                    cell.alignment = center_alignment
                    cell.border = thin_border
                    
                    # Thêm màu nền xám cho header
                    if cell.row == 1:  # Header row
                        cell.fill = header_fill
                        cell.font = openpyxl.styles.Font(bold=True)  # Thêm bold cho header
            
            # Add warning icon and highlight for identical sequences in File Name column
            for row in range(2, len(self.df_final_result) + 2):
                filename_cell = worksheet.cell(row=row, column=1)
                filename = filename_cell.value
                
                # Kiểm tra xem file có nằm trong nhóm file giống nhau không
                is_identical = False
                for group in self.identical_sequences.values():
                    if filename in group:
                        is_identical = True
                        break
                
                if is_identical:
                    filename_cell.value = f"⚠️ {filename}"
                    filename_cell.fill = warning_fill
                    filename_cell.comment = openpyxl.comments.Comment(
                        'This sequence has identical content with other sequence(s)',
                        'System'
                    )
            
            # Highlight cells with different values in other columns
            for col_num, col_name in enumerate(self.df_final_result.columns, start=1):
                column_letter = openpyxl.utils.get_column_letter(col_num)
                
                if col_name in self.different_params:
                    # Find the most common value in the column
                    most_common_value = self.df_final_result[col_name].mode().iloc[0]
                    
                    for row in range(2, len(self.df_final_result) + 2):
                        cell = worksheet.cell(row=row, column=col_num)  # Bỏ +1 vì enumerate đã start=1
                        # Highlight cells with values different from the most common
                        if str(cell.value) != str(most_common_value):
                            cell.fill = highlight_fill
                
                # Adjust column width for better readability
                max_length = max(len(str(cell.value)) for cell in worksheet[column_letter] if cell.value)
                adjusted_width = (max_length + 2) * 1.2
                worksheet.column_dimensions[column_letter].width = adjusted_width
            
            # Freeze top row and first column
            worksheet.freeze_panes = 'B2'
            
            writer.close()
            
            self.result_display.append(f"\nHighlighted file created: {highlight_file}")
            os.startfile(highlight_file)
        except Exception as e:
            error_msg = f"Error creating highlight file: {str(e)}"
            self.result_display.append(f"\n{error_msg}")
            QMessageBox.critical(self,
                               "Highlight File Error",
                               error_msg,
                               QMessageBox.StandardButton.Ok)

    def open_output_folder(self):
        try:
            if not hasattr(self, 'output_dir'):
                QMessageBox.warning(self,
                                  "No Output",
                                  "Output folder not created yet.",
                                  QMessageBox.StandardButton.Ok)
                return
            os.startfile(self.output_dir)
        except Exception as e:
            error_msg = f"Error opening output folder: {str(e)}"
            self.result_display.append(f"\n{error_msg}")
            QMessageBox.critical(self,
                               "Folder Access Error",
                               error_msg,
                               QMessageBox.StandardButton.Ok)

    def create_shadow_effect(self):
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(15)
        shadow.setXOffset(3)
        shadow.setYOffset(3)
        shadow.setColor(QColor(0, 0, 0, 45))
        return shadow

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = XMLComparisonApp()
    ex.show()
    sys.exit(app.exec())  # Note: exec() instead of exec_()