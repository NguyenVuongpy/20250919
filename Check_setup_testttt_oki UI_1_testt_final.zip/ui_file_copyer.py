
import os
import sys
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from PIL import Image, ImageDraw
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QWidget, QPushButton, 
    QLabel, QTextEdit, QFileDialog, QProgressBar, QMessageBox, 
    QHBoxLayout, QFrame, QGraphicsDropShadowEffect, QFormLayout, QDialog
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QSize
from PyQt6.QtGui import QFont, QPalette, QColor, QIcon
import openpyxl
from openpyxl.drawing.image import Image as ExcelImage
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment, PatternFill, Border, Side, Font # Import Border, Side, Font
import re
import rc.icons
from PyQt6 import QtCore, QtGui, QtWidgets
import json
import shutil


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setWindowTitle("PUC Tool Manager")
        self.centralWidget = QtWidgets.QWidget(MainWindow)
        MainWindow.setCentralWidget(self.centralWidget)
        MainWindow.resize(1200, 700)
        
        # Softer, eye-friendly color palette
        self.colors = {
            "primary": "#5B6CC3",      # Softer indigo
            "primary_light": "#7E8EE0", # Lighter indigo
            "secondary": "#4A9FCB",    # Softer sky blue
            "accent": "#8A7BC8",       # Softer violet
            "light": "#F5F7FA",        # Softer light background
            "light_card": "#FFFFFF",   # Card background
            "dark": "#2D3748",         # Softer dark text
            "medium": "#718096",       # Softer medium text
            "border": "#E2E8F0",       # Border color
            "success": "#48BB78",      # Softer green
            "warning": "#ED8936",      # Softer amber
            "error": "#F56565",        # Softer red
            "background": "#F1F5F9",   # Main background
        }
        
        self.main_layout = QtWidgets.QVBoxLayout(self.centralWidget)
        self.main_layout.setSpacing(20)
        self.main_layout.setContentsMargins(25, 25, 25, 25)

        # Header container with gradient background
        header_container = QWidget()
        header_container.setObjectName("headerContainer")
        header_container.setFixedHeight(90)
        header_container.setStyleSheet("""
            #headerContainer {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                    stop:0 #3498db, stop:1 #2980b9);
                border-radius: 12px;
            }
        """)

        header_layout = QHBoxLayout(header_container)
        header_layout.setContentsMargins(20, 0, 20, 0)

        # Icon in header with shadow effect
        icon_button = QtWidgets.QPushButton()
        icon_button.setFixedSize(70, 70)
        icon_button.setCursor(QtGui.QCursor(QtCore.Qt.CursorShape.PointingHandCursor))
        icon_button.setStyleSheet("""
            QPushButton {
                background: transparent;
                border: none;
                border-radius: 45px;
                padding: 10px;
            }
        """)
        
        # Create a more prominent shadow effect for the icon button
        icon_shadow = QtWidgets.QGraphicsDropShadowEffect()
        icon_shadow.setBlurRadius(15)
        icon_shadow.setXOffset(3)
        icon_shadow.setYOffset(3)
        icon_shadow.setColor(QtGui.QColor(0, 0, 0, 80))  # Increase shadow intensity
        icon_button.setGraphicsEffect(icon_shadow)
        
        # Set a larger icon for the button
        icon = QtGui.QIcon(":/icons/app_icon.png")
        icon_button.setIcon(icon)
        icon_button.setIconSize(QtCore.QSize(70, 70))  # Increase icon size
        
        # Add the icon button to the header layout
        header_layout.addWidget(icon_button)

        # Title container
        title_container = QVBoxLayout()
        title_container.setSpacing(-2)

        title_label = QLabel("PUC Tool Manager")
        title_label.setFont(QFont("Segoe UI", 20, QFont.Weight.Bold))
        title_label.setStyleSheet("color: white; padding: 0; margin: 0;")

        subtitle_label = QLabel("Sequence, INI, DLL File Manager")
        subtitle_label.setFont(QFont("Segoe UI", 10))
        subtitle_label.setStyleSheet("color: rgba(255, 255, 255, 0.85);")
        subtitle_label.setContentsMargins(0, -5, 0, 0)

        title_container.addWidget(title_label)
        title_container.addWidget(subtitle_label)

        header_layout.addLayout(title_container)
        header_layout.addStretch()

        # Manage Models button in header
        self.settings_button = QPushButton("")
        self.settings_button.setIcon(QIcon(":/icons/setting.png"))
        self.settings_button.setIconSize(QSize(60, 60)) # Adjust icon size for header
        self.settings_button.setFixedSize(60, 60) # Smaller fixed size
        self.settings_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.settings_button.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.2); /* Slightly transparent white */
                border: none;
                border-radius: 20px; /* Make it circular */
                padding: 5px;
                color: white;
            }
            QPushButton:hover {
                background-color: rgba(255, 255, 255, 0.3);
            }
            QPushButton:pressed {
                background-color: rgba(255, 255, 255, 0.4);
            }
        """)
        # Add a subtle shadow to the settings button
        settings_shadow = QtWidgets.QGraphicsDropShadowEffect()
        settings_shadow.setBlurRadius(8)
        settings_shadow.setXOffset(1)
        settings_shadow.setYOffset(1)
        settings_shadow.setColor(QtGui.QColor(0, 0, 0, 60))
        self.settings_button.setGraphicsEffect(settings_shadow)
        header_layout.addWidget(self.settings_button)

        self.main_layout.addWidget(header_container)

        # Main content area with larger left panel
        main_content_widget = QtWidgets.QWidget()
        main_content_layout = QtWidgets.QHBoxLayout(main_content_widget)
        main_content_layout.setSpacing(25)
        main_content_layout.setContentsMargins(0, 0, 0, 0)
        
        # Left panel - Controls (60% width - larger)
        left_panel = QtWidgets.QWidget()
        left_panel.setMaximumWidth(800)  # Larger left panel
        left_layout = QtWidgets.QVBoxLayout(left_panel)
        left_layout.setSpacing(20)
        left_layout.setContentsMargins(0, 0, 0, 0)
        
        # Line selection card
        self.line_card = QtWidgets.QWidget()
        self.line_card.setObjectName("line_card")
        self.line_card.setStyleSheet(f"""
            QWidget {{
                background-color: {self.colors['light_card']};
                border-radius: 12px;
                border: 1px solid {self.colors['border']};
            }}
        """)
        self.line_card.setGraphicsEffect(self.create_card_shadow())
        line_layout = QtWidgets.QHBoxLayout(self.line_card)
        line_layout.setContentsMargins(20, 15, 20, 15)
        line_layout.setSpacing(20)
        
        line_label = QtWidgets.QLabel("Select Lines:")
        line_label.setStyleSheet(f"""
            font-size: 14px;
            font-weight: bold;
            color: {self.colors['dark']};
            padding: 5px 0;
        """)
        line_layout.addWidget(line_label)
        
        for i in range(1, 5):
            checkbox = QtWidgets.QCheckBox(f"Line {i}")
            checkbox.setStyleSheet(f"""
                QCheckBox {{
                    font-size: 13px;
                    spacing: 8px;
                    color: {self.colors['dark']};
                    padding: 5px;
                }}
                QCheckBox::indicator {{
                    width: 20px;
                    height: 20px;
                    border: 2px solid {self.colors['primary']};
                    border-radius: 5px;
                }}
                QCheckBox::indicator:checked {{
                    background-color: {self.colors['primary']};
                    image: url(:/icons/check.png);
                }}
            """)
            line_layout.addWidget(checkbox)
        
        left_layout.addWidget(self.line_card)
        
        # MONO and COLOR sections
        mono_color_widget = QtWidgets.QWidget()
        mono_color_layout = QtWidgets.QHBoxLayout(mono_color_widget)
        mono_color_layout.setContentsMargins(0, 0, 0, 0)
        mono_color_layout.setSpacing(20)
        
        # MONO section - wider
        mono_widget = self.create_section_widget("MONO", self.colors['primary'])
        mono_widget.setMinimumWidth(350)  # Wider MONO section
        mono_layout = mono_widget.layout()
        self.setup_mono_controls(mono_layout)
        mono_color_layout.addWidget(mono_widget)
        
        # COLOR section - wider
        color_widget = self.create_section_widget("COLOR", self.colors['accent'])
        color_widget.setMinimumWidth(350)  # Wider COLOR section
        color_layout = color_widget.layout()
        self.setup_color_controls(color_layout)
        mono_color_layout.addWidget(color_widget)
        
        left_layout.addWidget(mono_color_widget)
        
        # Custom styled check buttons with unique styles
        check_buttons_widget = QtWidgets.QWidget()
        check_buttons_layout = QtWidgets.QHBoxLayout(check_buttons_widget)
        check_buttons_layout.setSpacing(15)
        check_buttons_layout.setContentsMargins(0, 0, 0, 0)
        
        self.reset_all_history_button = self.create_modern_button("Reset History", ":/icons/clear.png", self.colors['warning'])
        self.reset_all_history_button.setFixedSize(120, 35) # Smaller size
        self.reset_all_history_button.setStyleSheet(f"""
            QPushButton {{
                background-color: {self.colors['warning']};
                color: white;
                border: none;
                padding: 8px 12px;
                border-radius: 8px;
                font-weight: 500;
                font-size: 12px;
            }}
            QPushButton:hover {{
                background-color: {self.adjust_color(self.colors['warning'], 15)};
            }}
            QPushButton:pressed {{
                background-color: {self.adjust_color(self.colors['warning'], -15)};
            }}
        """)
        check_buttons_layout.addWidget(self.reset_all_history_button)

        # Sequence Check Button - Blue outline style
        self.sequence_check_button = QtWidgets.QPushButton("Sequence Check")
        self.sequence_check_button.setIcon(QtGui.QIcon(":/icons/sequence.png"))
        self.sequence_check_button.setIconSize(QSize(22, 22))
        self.sequence_check_button.setMinimumHeight(45)
        self.sequence_check_button.setStyleSheet(f"""
            QPushButton {{
                background-color: transparent;
                color: {self.colors['primary']};
                border: 2px solid {self.colors['primary']};
                padding: 10px 18px;
                border-radius: 10px;
                font-weight: bold;
                font-size: 13px;
            }}
            QPushButton:hover {{
                background-color: {self.colors['primary']}15;
                border: 2px solid {self.adjust_color(self.colors['primary'], 20)};
            }}
            QPushButton:pressed {{
                background-color: {self.colors['primary']}25;
                padding: 11px 18px 9px 18px;
            }}
        """)
        self.sequence_check_button.setGraphicsEffect(self.create_outline_button_shadow(self.colors['primary']))
        
        # INI Check Button - Green outline style
        self.ini_check_button = QtWidgets.QPushButton("INI Check")
        self.ini_check_button.setIcon(QtGui.QIcon(":/icons/ini.png"))
        self.ini_check_button.setIconSize(QSize(22, 22))
        self.ini_check_button.setMinimumHeight(45)
        self.ini_check_button.setStyleSheet(f"""
            QPushButton {{
                background-color: transparent;
                color: {self.colors['success']};
                border: 2px solid {self.colors['success']};
                padding: 10px 18px;
                border-radius: 10px;
                font-weight: bold;
                font-size: 13px;
            }}
            QPushButton:hover {{
                background-color: {self.colors['success']}15;
                border: 2px solid {self.adjust_color(self.colors['success'], 20)};
            }}
            QPushButton:pressed {{
                background-color: {self.colors['success']}25;
                padding: 11px 18px 9px 18px;
            }}
        """)
        self.ini_check_button.setGraphicsEffect(self.create_outline_button_shadow(self.colors['success']))
        
        # DLL Check Button - Purple outline style
        self.dll_check_button = QtWidgets.QPushButton("DLL Check")
        self.dll_check_button.setIcon(QtGui.QIcon(":/icons/dll.png"))
        self.dll_check_button.setIconSize(QSize(22, 22))
        self.dll_check_button.setMinimumHeight(45)
        self.dll_check_button.setStyleSheet(f"""
            QPushButton {{
                background-color: transparent;
                color: {self.colors['accent']};
                border: 2px solid {self.colors['accent']};
                padding: 10px 18px;
                border-radius: 10px;
                font-weight: bold;
                font-size: 13px;
            }}
            QPushButton:hover {{
                background-color: {self.colors['accent']}15;
                border: 2px solid {self.adjust_color(self.colors['accent'], 20)};
            }}
            QPushButton:pressed {{
                background-color: {self.colors['accent']}25;
                padding: 11px 18px 9px 18px;
            }}
        """)
        self.dll_check_button.setGraphicsEffect(self.create_outline_button_shadow(self.colors['accent']))
        
        check_buttons_layout.addWidget(self.sequence_check_button)
        check_buttons_layout.addWidget(self.ini_check_button)
        check_buttons_layout.addWidget(self.dll_check_button)
        
        left_layout.addWidget(check_buttons_widget)
        left_layout.addStretch(1)
        
        main_content_layout.addWidget(left_panel, 2)  # Left panel takes 2/3 of space
        
        # Right panel - Log (40% width)
        right_panel = QtWidgets.QWidget()
        right_layout = QtWidgets.QVBoxLayout(right_panel)
        right_layout.setSpacing(20)
        right_layout.setContentsMargins(0, 0, 0, 0)
        
        log_widget = QtWidgets.QWidget()
        log_widget.setStyleSheet(f"""
            QWidget {{
                background-color: {self.colors['light_card']};
                border-radius: 14px;
                border: 1px solid {self.colors['border']};
            }}
        """)
        log_widget.setGraphicsEffect(self.create_card_shadow())
        log_layout = QtWidgets.QVBoxLayout(log_widget)
        log_layout.setContentsMargins(25, 25, 25, 25)
        
        log_header = QtWidgets.QLabel("Operation Log")
        log_header.setStyleSheet(f"""
            QLabel {{
                font-size: 18px;
                font-weight: bold;
                color: {self.colors['dark']};
                padding: 0 0 10px 0;
                border-bottom: 2px solid {self.colors['primary']};
            }}
        """)
        log_layout.addWidget(log_header)
        
        self.log_text = QtWidgets.QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setStyleSheet(f"""
            QTextEdit {{
                background-color: {self.colors['light']};
                border-radius: 10px;
                padding: 15px;
                font-family: 'Segoe UI', 'Roboto', sans-serif;
                font-size: 12px;
                color: {self.colors['dark']};
                border: 1px solid {self.colors['border']};
            }}
        """)
        log_layout.addWidget(self.log_text)
        right_layout.addWidget(log_widget)
        
        main_content_layout.addWidget(right_panel, 1)  # Right panel takes 1/3 of space
        
        self.main_layout.addWidget(main_content_widget)
        
        # Footer
        footer_widget = QtWidgets.QWidget()
        footer_widget.setStyleSheet("background: transparent;")
        footer_layout = QtWidgets.QHBoxLayout(footer_widget)
        footer_layout.setContentsMargins(10, 0, 10, 0)
        
        author_label = QtWidgets.QLabel("Developed by nguyenvanvuong1")
        author_label.setStyleSheet(f"""
            color: {self.colors['medium']}; 
            font-style: italic; 
            font-size: 12px;
        """)
        footer_layout.addWidget(author_label)
        
        footer_layout.addStretch(1)
        
        status_indicator = QtWidgets.QWidget()
        status_indicator.setFixedSize(12, 12)
        status_indicator.setStyleSheet(f"""
            background-color: {self.colors['success']};
            border-radius: 6px;
        """)
        footer_layout.addWidget(status_indicator)
        
        status_label = QtWidgets.QLabel("Ready")
        status_label.setStyleSheet(f"""
            color: {self.colors['medium']}; 
            font-size: 12px;
            padding: 0 0 0 5px;
        """)
        footer_layout.addWidget(status_label)
        
        footer_layout.addSpacing(15)
        
        version_label = QtWidgets.QLabel("v1.0.0")
        version_label.setStyleSheet(f"""
            color: {self.colors['medium']}; 
            font-size: 12px;
        """)
        footer_layout.addWidget(version_label)
        
        self.main_layout.addWidget(footer_widget)
        
        # Set application styles with softer background
        self.apply_modern_styles(MainWindow)

    def create_section_widget(self, title, color):
        widget = QtWidgets.QWidget()
        widget.setStyleSheet(f"""
            QWidget {{
                background-color: {self.colors['light_card']};
                border-radius: 14px;
                border: 1px solid {self.colors['border']};
            }}
        """)
        widget.setGraphicsEffect(self.create_card_shadow())
        layout = QtWidgets.QVBoxLayout(widget)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        title_label = QtWidgets.QLabel(title)
        title_label.setStyleSheet(f"""
            QLabel {{
                font-size: 16px;
                font-weight: bold;
                color: {color};
                padding-bottom: 8px;
                border-bottom: 2px solid {color};
            }}
        """)
        layout.addWidget(title_label)
        
        return widget

    def create_modern_button(self, text, icon_path, color):
        button = QtWidgets.QPushButton(text)
        button.setIcon(QtGui.QIcon(icon_path))
        button.setIconSize(QSize(22, 22))
        button.setMinimumHeight(42)
        button.setStyleSheet(f"""
            QPushButton {{
                background-color: {color};
                color: white;
                border: none;
                padding: 10px 18px;
                border-radius: 10px;
                font-weight: bold;
                font-size: 13px;
            }}
            QPushButton:hover {{
                background-color: {self.adjust_color(color, 15)};
            }}
            QPushButton:pressed {{
                background-color: {self.adjust_color(color, -15)};
                padding: 11px 18px 9px 18px;
            }}
            QPushButton:disabled {{
                background-color: {self.colors['border']};
                color: {self.colors['medium']};
            }}
        """)
        button.setGraphicsEffect(self.create_button_shadow(color))
        return button

    def adjust_color(self, color, amount):
        # Convert hex to RGB
        r = int(color[1:3], 16)
        g = int(color[3:5], 16)
        b = int(color[5:7], 16)
        
        # Adjust brightness
        r = max(0, min(255, r + amount))
        g = max(0, min(255, g + amount))
        b = max(0, min(255, b + amount))
        
        # Convert back to hex
        return f"#{r:02x}{g:02x}{b:02x}"

    def setup_mono_controls(self, layout):
        # Common Path Input
        common_path_container = QtWidgets.QWidget()
        common_path_layout = QtWidgets.QVBoxLayout(common_path_container)
        common_path_layout.setContentsMargins(0, 0, 0, 0)
        common_path_layout.setSpacing(8)
        
        common_path_label = QtWidgets.QLabel("Common Path Mono:")
        common_path_label.setStyleSheet(f"""
            color: {self.colors['dark']}; 
            font-size: 13px; 
            font-weight: 500;
        """)
        common_path_layout.addWidget(common_path_label)
        
        self.common_path_mono = QtWidgets.QComboBox()
        self.common_path_mono.setEditable(True)
        self.common_path_mono.setPlaceholderText("Enter common path (e.g., C:\\Program Files\\AppFolder or \\\\10.0.0.1\\SharedFolder)")
        self.common_path_mono.setStyleSheet(self.get_combo_style())
        self.common_path_mono.setMinimumHeight(30) # Reduced height
        common_path_layout.addWidget(self.common_path_mono)
        
        layout.addWidget(common_path_container)

        # Filename Input
        filename_container = QtWidgets.QWidget()
        filename_layout = QtWidgets.QVBoxLayout(filename_container)
        filename_layout.setContentsMargins(0, 0, 0, 0)
        filename_layout.setSpacing(8)
        
        filename_label = QtWidgets.QLabel("Mono File Name to Copy:")
        filename_label.setStyleSheet(f"""
            color: {self.colors['dark']}; 
            font-size: 13px; 
            font-weight: 500;
        """)
        filename_layout.addWidget(filename_label)
        
        self.filename_mono = QtWidgets.QComboBox()
        self.filename_mono.setEditable(True)
        self.filename_mono.setPlaceholderText("Enter filename (e.g., MySequence.seqxc)")
        self.filename_mono.setStyleSheet(self.get_combo_style())
        self.filename_mono.setMinimumHeight(30) # Reduced height
        filename_layout.addWidget(self.filename_mono)
        
        layout.addWidget(filename_container)
        
        self.copy_mono_button = self.create_modern_button(
            "Copy File Mono", ":/icons/loading.png", self.colors['primary'])
        layout.addWidget(self.copy_mono_button)
        
        layout.addStretch(1)

    def setup_color_controls(self, layout):
        # Common Path Input
        common_path_container = QtWidgets.QWidget()
        common_path_layout = QtWidgets.QVBoxLayout(common_path_container)
        common_path_layout.setContentsMargins(0, 0, 0, 0)
        common_path_layout.setSpacing(8)
        
        common_path_label = QtWidgets.QLabel("Common Path Color:")
        common_path_label.setStyleSheet(f"""
            color: {self.colors['dark']}; 
            font-size: 13px; 
            font-weight: 500;
        """)
        common_path_layout.addWidget(common_path_label)
        
        self.common_path_color = QtWidgets.QComboBox()
        self.common_path_color.setEditable(True)
        self.common_path_color.setPlaceholderText("Enter common path (e.g., C:\\Program Files\\AppFolder or \\\\10.0.0.1\\SharedFolder)")
        self.common_path_color.setStyleSheet(self.get_combo_style())
        self.common_path_color.setMinimumHeight(30) # Reduced height
        common_path_layout.addWidget(self.common_path_color)
        
        layout.addWidget(common_path_container)

        # Filename Input
        filename_container = QtWidgets.QWidget()
        filename_layout = QtWidgets.QVBoxLayout(filename_container)
        filename_layout.setContentsMargins(0, 0, 0, 0)
        filename_layout.setSpacing(8)
        
        filename_label = QtWidgets.QLabel("Color File Name to Copy:")
        filename_label.setStyleSheet(f"""
            color: {self.colors['dark']}; 
            font-size: 13px; 
            font-weight: 500;
        """)
        filename_layout.addWidget(filename_label)
        
        self.filename_color = QtWidgets.QComboBox()
        self.filename_color.setEditable(True)
        self.filename_color.setPlaceholderText("Enter filename (e.g., MySequence.seqxc)")
        self.filename_color.setStyleSheet(self.get_combo_style())
        self.filename_color.setMinimumHeight(30) # Reduced height
        filename_layout.addWidget(self.filename_color)
        
        layout.addWidget(filename_container)
        
        self.copy_color_button = self.create_modern_button(
            "Copy File Color", ":/icons/simplify.png", self.colors['accent'])
        layout.addWidget(self.copy_color_button)
        
        layout.addStretch(1)

    def get_lineedit_style(self):
        style = """
            QLineEdit {{
                background-color: {light};
                border: 2px solid {border};
                border-radius: 8px;
                padding: 8px 15px;
                font-size: 13px;
                color: {dark};
                min-height: 36px;
            }}
            QLineEdit:focus {{
                border-color: {primary};
                background-color: white;
            }}
            QLineEdit::placeholder {{
                color: {medium};
            }}
        """.format(
            light=self.colors['light'],
            border=self.colors['border'],
            dark=self.colors['dark'],
            primary=self.colors['primary'],
            medium=self.colors['medium']
        )
        return style

    def get_combo_style(self):
        return f"""
            QComboBox {{
                background-color: #ffffff;
                border: 2px solid #3498db;
                border-radius: 8px;
                padding: 5px 10px;
                min-width: 200px;
                color: #2c3e50;
                font-size: 12px;
            }}
            QComboBox:hover {{
                border: 2px solid #3498db;
                background-color: #f7fbff;
            }}
            QComboBox:focus {{
                border: 2px solid #3498db;
                background-color: white;
            }}

            /* Nút dropdown */
            QComboBox::drop-down {{
                border: none;
                padding-right: 10px;
            }}
            QComboBox::down-arrow {{
                image: url(:/icons/down_arrow.png);
                width: 12px;
                height: 12px;
            }}

            /* Danh sách thả xuống */
            QComboBox QAbstractItemView {{
                background: white;  /* Nền trắng */
                border: 1px solid rgba(0, 0, 0, 0.2);  /* Viền đổ bóng nhẹ */
                border-radius: 6px;
                padding: 2px;
                outline: 0px;
                selection-background-color: transparent;
            }}

            /* Giảm padding danh sách */
            QComboBox QAbstractItemView::item {{
                font-size: 14px;
                padding: 3px 10px;
                color: #2c3e50;
                background-color: white; /* Nền trắng */
            }}

            /* Hover nổi bật hơn */
            QComboBox QAbstractItemView::item:hover {{
                color: white;
                background-color: #00c2c7; /* Nền xanh ngọc */
                border-radius: 4px; /* Bo góc nhẹ */
            }}

            /* Mục được chọn */
            QComboBox QAbstractItemView::item:selected {{
                color: white;
                background-color: #00a2b3; /* Xanh ngọc đậm hơn */
                border-radius: 4px;
            }}
        """

    def apply_modern_styles(self, MainWindow):
        MainWindow.setStyleSheet(f"""
            QMainWindow {{
                background-color: {self.colors['background']};
                color: {self.colors['dark']};
                font-family: 'Segoe UI', 'Roboto', sans-serif;
            }}
            QLabel {{
                color: {self.colors['dark']};
            }}
        """)

    def create_card_shadow(self):
        shadow = QtWidgets.QGraphicsDropShadowEffect()
        shadow.setBlurRadius(20)
        shadow.setXOffset(0)
        shadow.setYOffset(4)
        shadow.setColor(QtGui.QColor(0, 0, 0, 20))  # Softer shadow
        return shadow

    def create_button_shadow(self, color):
        shadow = QtWidgets.QGraphicsDropShadowEffect()
        shadow.setBlurRadius(15)
        shadow.setXOffset(0)
        shadow.setYOffset(5)
        shadow.setColor(QtGui.QColor(color + "60"))  # Softer shadow
        return shadow

    def create_outline_button_shadow(self, color):
        shadow = QtWidgets.QGraphicsDropShadowEffect()
        shadow.setBlurRadius(10)
        shadow.setXOffset(0)
        shadow.setYOffset(3)
        shadow.setColor(QtGui.QColor(color + "40"))  # Very subtle shadow for outline buttons
        return shadow