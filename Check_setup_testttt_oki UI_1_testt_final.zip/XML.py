# Module to work with .xml file
import xml.etree.ElementTree as ET

# Function to read text value of one tag in XML tree.
# If xml file is non-exist or the xpath to the tag is empty, then return ""
# @param xmlfile:   xml file object, not a path to xml file.
#                   This to avoid mutiple parsing xml file when multiple call to this function.
# @param xpath: XPath to the desired tag.
# Return: the text value at desired tag or empty string.
def xmlReadXPathList(xmlfile, xpath):
    """
    Lấy tất cả các giá trị từ các phần tử theo xpath
    @param xmlfile: xml file object
    @param xpath: XPath đến các phần tử cần lấy
    Return: danh sách các giá trị hoặc chuỗi rỗng nếu không tìm thấy
    """
    retVal = []

    if xmlfile is None:
        return retVal

    try:
        xmlroot = xmlfile.getroot()
        
        # Nếu xpath kết thúc bằng /text(), lấy text của tất cả các phần tử
        if xpath.endswith('/text()'):
            elements = xmlroot.findall(xpath[:-7])
            retVal = [elem.text.strip() for elem in elements if elem is not None and elem.text is not None]

        # Nếu xpath kết thúc bằng /@type, lấy giá trị của thuộc tính type
        elif xpath.endswith('/@type'):
            elements = xmlroot.findall(xpath[:-6])
            retVal = [elem.get('type', '') for elem in elements if elem is not None]

        # Nếu xpath kết thúc bằng /@xsi:type, lấy giá trị của thuộc tính xsi:type
        elif xpath.endswith('/@xsi:type'):
            elements = xmlroot.findall(xpath[:-10])
            retVal = [elem.get('{http://www.w3.org/2001/XMLSchema-instance}type', '') for elem in elements if elem is not None]

        # Nếu xpath kết thúc bằng /local-name(), lấy tên của tất cả các phần tử
        elif xpath.endswith('/local-name()'):
            elements = xmlroot.findall(xpath[:-12])
            retVal = [elem.tag for elem in elements if elem is not None]

        # Trường hợp còn lại: lấy giá trị trực tiếp
        else:
            elements = xmlroot.findall(xpath)
            retVal = [elem.text.strip() for elem in elements if elem is not None and elem.text is not None]

    except Exception as e:
        return ['Not found']  # Trả về danh sách chứa lỗi mặc định nếu có vấn đề

    return retVal

def xmlReadXPath(xmlfile, xpath):
    """
    Đọc giá trị của một hoặc nhiều phần tử theo xpath
    Nếu xpath trỏ đến nhiều phần tử, sẽ trả về chuỗi chứa tất cả các giá trị được phân tách bằng dấu phẩy
    """
    values = xmlReadXPathList(xmlfile, xpath)
    if not values:
        return ""
    return ", ".join(values)


# Collect all elements at the level indicated by 'xpath' argument
# Then iterate through each element and read the first and second subelement of it
# Construct a dictionary with 1st subelement as 'key', 2nd subelement as 'value'
# Append the dictionary to the list then return the list. 
# If xml file name is empty or incorrect format or file non-exist then resultList will be None
# @param xmlFileName. Type: file name or file object of xml file
# @param xpath. Type: string. An a path to a xml element level.
# Return: List of dictionary objects
#
def xmlParseToListDict(xmlfile, xpath, clsname=None):

    retVal = [] # To be returned
    
    # Extract xml element value
    try:
        xml = ET.parse(xmlfile)

        # Get all nodes at 'xpath' level in 'xmlfile' tree
        nodes = [node for node in xml.findall(xpath) if node is not None]
        for node in nodes:
            try:
                key = node[0].text
                value = node[1].text
                if key and value:
                    if clsname:
                        retVal.append(clsname(key, value))
                    else:
                        retVal.append({key: value}) 
            except:
                continue
    except:
        return None
        # print("Unable to parse xml file or the xpath does not contain any element")

    return retVal


# Function to return an xml file as a reference
# @param: path. A string address of xml file
def xmlGet(path):
    try:
        return  ET.parse(path)
    except:
        return None